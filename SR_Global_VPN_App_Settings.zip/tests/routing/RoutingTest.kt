import android.content.Context
import com.payaq.opengatevpn.SrRouting
import de.blinkt.openvpn.VpnProfile
fun main(){
 val c=Context();val p=VpnProfile()
 check(!SrRouting.read(c).custom);SrRouting.apply(c,p);check(p.mAllowedAppsVpn.isEmpty()&&p.mAllowedAppsVpnAreDisallowed&&!p.mAllowAppVpnBypass)
 check(SrRouting.apps(c).map{it.id}==listOf("app.one","app.two"))
 check(!SrRouting.save(c,SrRouting.Choice(true,emptySet())))
 check(SrRouting.save(c,SrRouting.Choice(true,setOf("app.one"))));SrRouting.apply(c,p);check(!p.mAllowedAppsVpnAreDisallowed&&p.mAllowedAppsVpn==setOf("app.one",c.packageName))
 check(SrRouting.save(c,SrRouting.Choice(true,setOf("app.one","app.two"))));SrRouting.apply(c,p);check(p.mAllowedAppsVpn==setOf("app.one","app.two",c.packageName))
 c.packageManager.installed.remove("app.one");SrRouting.apply(c,p);check(p.mAllowedAppsVpn==setOf("app.two",c.packageName))
 c.packageManager.installed.remove("app.two");check(runCatching{SrRouting.apply(c,p)}.isFailure)
 check(SrRouting.save(c,SrRouting.Choice(false,emptySet())));SrRouting.apply(c,p);check(p.mAllowedAppsVpn.isEmpty()&&p.mAllowedAppsVpnAreDisallowed)
 println("Routing tests passed: defaults, single/multiple, missing apps, no selection, reset")
}
