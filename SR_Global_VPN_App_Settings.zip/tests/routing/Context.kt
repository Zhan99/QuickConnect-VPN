package android.content
import android.content.pm.PackageManager
open class Context(val packageName:String="com.srcreationfarm.globalvpn",val packageManager:PackageManager=PackageManager()) {
 companion object {const val MODE_PRIVATE=0}
 private val p=SharedPreferences()
 fun getSharedPreferences(name:String,mode:Int)=p
}
class Intent(val action:String){companion object{const val ACTION_MAIN="main";const val CATEGORY_LAUNCHER="launcher"};fun addCategory(s:String)=this}
class SharedPreferences { private val m=mutableMapOf<String,Any>();fun getBoolean(k:String,d:Boolean)=m[k] as? Boolean ?: d; @Suppress("UNCHECKED_CAST") fun getStringSet(k:String,d:Set<String>)=m[k] as? Set<String> ?: d;fun edit()=Editor();inner class Editor {fun putBoolean(k:String,v:Boolean)=apply{m[k]=v};fun putStringSet(k:String,v:Set<String>)=apply{m[k]=v};fun commit()=true}}
