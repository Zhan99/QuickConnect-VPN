package de.blinkt.openvpn
class VpnProfile {var mAllowedAppsVpn=hashSetOf<String>();var mAllowedAppsVpnAreDisallowed=true;var mAllowAppVpnBypass=true}
