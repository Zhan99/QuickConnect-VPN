package android.content.pm
import android.content.Intent
class PackageManager { class NameNotFoundException:Exception();val installed=mutableSetOf("app.one","app.two","com.srcreationfarm.globalvpn");fun queryIntentActivities(i:Intent,flags:Int)=installed.map{ResolveInfo(ActivityInfo(it))};fun getApplicationInfo(id:String,flags:Int):Any=if(id in installed) Any() else throw NameNotFoundException() }
class ActivityInfo(val packageName:String)
class ResolveInfo(val activityInfo:ActivityInfo){fun loadLabel(pm:PackageManager):CharSequence=activityInfo.packageName}
