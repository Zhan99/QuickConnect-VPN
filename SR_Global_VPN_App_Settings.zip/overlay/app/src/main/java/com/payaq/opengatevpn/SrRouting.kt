package com.payaq.opengatevpn

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import de.blinkt.openvpn.VpnProfile

/** Local-only routing preferences. Applied on every new OpenVPN profile. */
object SrRouting {
    private const val PREF = "sr_routing"
    data class Choice(val custom: Boolean, val packages: Set<String>)
    fun read(context: Context): Choice {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return Choice(p.getBoolean("custom", false), p.getStringSet("packages", emptySet())?.toSet() ?: emptySet())
    }
    fun save(context: Context, choice: Choice): Boolean {
        if (choice.custom && choice.packages.isEmpty()) return false
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putBoolean("custom", choice.custom).putStringSet("packages", choice.packages.toSet()).commit()
    }
    data class App(val id: String, val label: String)
    fun apps(context: Context): List<App> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0).mapNotNull { info ->
            val id = info.activityInfo.packageName
            if (id == context.packageName) null else App(id, info.loadLabel(pm).toString())
        }.distinctBy { it.id }.sortedWith(compareBy<App, String>(String.CASE_INSENSITIVE_ORDER) { it.label })
    }
    fun apply(context: Context, profile: VpnProfile) {
        val choice = read(context)
        val allowed = if (choice.custom) {
            val installed = choice.packages.filter { id ->
                id != context.packageName && try { context.packageManager.getApplicationInfo(id, 0); true }
                catch (_: PackageManager.NameNotFoundException) { false }
            }.toSet()
            require(installed.isNotEmpty()) { "No selected apps are installed. Update VPN app selection." }
            installed + context.packageName // diagnostics must measure the VPN exit, not the direct IP
        } else emptySet()
        profile.mAllowedAppsVpn = HashSet(allowed)
        profile.mAllowedAppsVpnAreDisallowed = !choice.custom
        profile.mAllowAppVpnBypass = false
    }
}
