package com.payaq.opengatevpn

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.widget.*

class SrAppSettingsActivity : Activity() {
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val old = SrRouting.read(this)
        var custom = savedInstanceState?.getBoolean("custom") ?: old.custom
        val selected = (savedInstanceState?.getStringArrayList("selected")?.toSet() ?: old.packages).toMutableSet()
        currentSelection = selected
        val apps = SrRouting.apps(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(36),dp(16),dp(20)); setBackgroundColor(Color.rgb(12,25,37)) }
        setContentView(root)
        fun label(text: String, size: Float = 15f) = TextView(this).apply { this.text=text; textSize=size; setTextColor(Color.WHITE); setPadding(0,dp(5),0,dp(5)); root.addView(this) }
        label("VPN app selection", 24f)
        label("Choose all apps or only selected apps. Disconnect before saving changes; reconnect to apply. SR Global VPN is also included for IP diagnostics. Android lockdown can block excluded apps.")
        val modes = RadioGroup(this).apply { orientation=RadioGroup.VERTICAL }
        val all = RadioButton(this).apply { id=android.view.View.generateViewId(); text="All apps"; setTextColor(Color.WHITE) }
        val only = RadioButton(this).apply { id=android.view.View.generateViewId(); text="Selected apps only"; setTextColor(Color.WHITE) }
        modes.addView(all); modes.addView(only); root.addView(modes)
        modes.check(if(custom) only.id else all.id)
        currentCustom=custom
        val count = label("")
        val search = EditText(this).apply { hint="Search installed apps"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }; root.addView(search)
        val scroll=ScrollView(this); val list=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}; scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        fun updateCount() { count.text=if(custom) "${selected.count { id -> apps.any { it.id==id } }} selected" else "All apps use VPN" }
        fun render() {
            list.removeAllViews(); val q=search.text.toString().trim()
            search.isEnabled=custom
            if(!custom){updateCount();return}
            val matches=apps.filter { it.label.contains(q,true)||it.id.contains(q,true) }
            if(matches.isEmpty()) list.addView(TextView(this).apply {text="No matching launchable apps";setTextColor(Color.WHITE)})
            matches.forEach { app -> list.addView(CheckBox(this).apply {
                text="${app.label}\n${app.id}";setTextColor(Color.WHITE);isChecked=app.id in selected
                setOnCheckedChangeListener { _, checked -> if(checked) selected.add(app.id) else selected.remove(app.id);updateCount() }
            }) }; updateCount()
        }
        modes.setOnCheckedChangeListener { _, id -> custom=id==only.id; currentCustom=custom;render() }
        search.addTextChangedListener(object:TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()};override fun afterTextChanged(s:Editable?){} })
        val save=Button(this).apply {text="Save settings";isAllCaps=false};root.addView(save)
        save.setOnClickListener {
            val cm=getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            if (intent.getBooleanExtra("sr_busy",false) || cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN)==true) {
                Toast.makeText(this,"Return to VPN, disconnect, then reopen settings.",Toast.LENGTH_LONG).show();return@setOnClickListener
            }
            val valid=selected.intersect(apps.map { it.id }.toSet())
            if(custom&&valid.isEmpty()){Toast.makeText(this,"Select at least one app.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
            if(SrRouting.save(this,SrRouting.Choice(custom,valid))){Toast.makeText(this,"Saved. Applies on next VPN connection.",Toast.LENGTH_LONG).show();finish()}
            else Toast.makeText(this,"Could not save settings.",Toast.LENGTH_SHORT).show()
        }
        root.addView(Button(this).apply {text="Cancel";isAllCaps=false;setOnClickListener{finish()}})
        render()
    }
    private var currentCustom=false
    private var currentSelection: MutableSet<String> = mutableSetOf()
    override fun onSaveInstanceState(outState: Bundle) { outState.putBoolean("custom",currentCustom);outState.putStringArrayList("selected",ArrayList(currentSelection));super.onSaveInstanceState(outState) }
}
