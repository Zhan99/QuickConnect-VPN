package com.payaq.opengatevpn

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.payaq.opengatevpn.ui.main.ConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.util.Locale
import javax.net.ssl.HttpsURLConnection

@Composable
fun SrOverflow(state: ConnectionState, refresh: () -> Unit) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    val busy = state in setOf(ConnectionState.CONNECTED, ConnectionState.CONNECTING, ConnectionState.RECONNECTING, ConnectionState.PAUSED)
    Box {
        IconButton(onClick = { expanded = true }) { Text("⋮", style = MaterialTheme.typography.headlineMedium) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Settings · VPN app selection") }, onClick = {
                expanded = false
                context.startActivity(Intent(context, SrAppSettingsActivity::class.java).putExtra("sr_busy", busy))
            })
            DropdownMenuItem(text = { Text("IP check · Speed test · Theme · About") }, onClick = {
                expanded = false; context.startActivity(Intent(context, SrToolsActivity::class.java))
            })
            DropdownMenuItem(text = { Text("Android VPN settings / Kill switch") }, onClick = {
                expanded = false
                try { context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }
                catch (_: Exception) { Toast.makeText(context,"Open VPN settings in Android Settings",Toast.LENGTH_LONG).show() }
            })
            DropdownMenuItem(text = { Text("Refresh server list") }, onClick = { expanded = false; refresh() })
        }
    }
}

/** Read only through the current VPN Network; never fall back to the physical interface. */
internal object SrExitLookup {
    data class Exit(val ip: String, val country: String?, val city: String?)
    private fun text(network: Network, url: String): String {
        val connection = network.openConnection(URL(url)) as HttpsURLConnection
        try {
            connection.connectTimeout = 7000; connection.readTimeout = 7000
            connection.instanceFollowRedirects = false; connection.useCaches = false
            check(connection.responseCode == 200)
            return connection.inputStream.bufferedReader().use { reader ->
                val buf = CharArray(4096); val n = reader.read(buf)
                if (n < 0) error("Empty response")
                val out = StringBuilder().append(buf,0,n)
                while (true) { val count = reader.read(buf); if(count < 0) break; out.append(buf,0,count); check(out.length <= 16384) }
                out.toString()
            }
        } finally { connection.disconnect() }
    }
    private fun validIp(s:String):Boolean {
        if(s.length !in 2..45) return false
        return if(s.contains(':')) s.matches(Regex("[0-9A-Fa-f:.]+")) && runCatching { java.net.InetAddress.getByName(s) }.isSuccess
        else s.split('.').let { a -> a.size == 4 && a.all { it.isNotEmpty() && it.all(Char::isDigit) && (it.toIntOrNull() ?: -1) in 0..255 } }
    }
    private fun JSONObject.field(key:String):String? = optString(key, "").trim().takeIf { it.isNotEmpty() && !it.equals("null",true) }?.take(100)
    private fun vpn(cm:ConnectivityManager): Network? = cm.activeNetwork?.takeIf { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN)==true }
    fun lookup(context: Context): Exit? {
        val cm=context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network=vpn(cm) ?: return null
        val result = try {
            val j=JSONObject(text(network,"https://get.geojs.io/v1/ip/geo.json"))
            val ip=j.field("ip") ?: error("Missing IP")
            check(validIp(ip))
            Exit(ip,j.field("country"),j.field("city"))
        } catch (_: Exception) {
            if(vpn(cm)!=network) return null
            try { val ip=text(network,"https://api.ipify.org").trim();check(validIp(ip));Exit(ip,null,null) }
            catch (_: Exception) { return null }
        }
        return result.takeIf { vpn(cm)==network }
    }
}

@Composable
fun SrExitCard(state: ConnectionState, serverIp: String?, serverCountry: String?) {
    val context = LocalContext.current.applicationContext
    var refresh by remember { mutableStateOf(0) }
    var result by remember(state, serverIp, refresh) { mutableStateOf<SrExitLookup.Exit?>(null) }
    var loading by remember(state, serverIp, refresh) { mutableStateOf(state==ConnectionState.CONNECTED) }
    LaunchedEffect(state, serverIp, refresh) {
        if (state != ConnectionState.CONNECTED) return@LaunchedEffect
        // Give Android time to publish the newly established VPN network.
        repeat(3) {
            val found = withContext(Dispatchers.IO) { SrExitLookup.lookup(context) }
            if(found != null) {result=found;loading=false;return@LaunchedEffect}
            delay(1200)
        }
        loading=false
    }
    Card(modifier=Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=3.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) {
                Text(if(state==ConnectionState.CONNECTED) "VPN exit location" else "VPN not connected",style=MaterialTheme.typography.titleSmall)
                if(state==ConnectionState.CONNECTED) TextButton(onClick={refresh++},enabled=!loading,contentPadding=PaddingValues(horizontal=6.dp)) {Text("Refresh")}
            }
            if(state==ConnectionState.CONNECTED) {
                val exit=result
                Text("Country: ${exit?.country ?: "Unknown"}   ·   City: ${exit?.city ?: "Unknown"}", style=MaterialTheme.typography.bodySmall)
                Text("Public IP: ${exit?.ip ?: if(loading) "Checking…" else "Unavailable"}",style=MaterialTheme.typography.bodyMedium)
                Text(if(loading) "Checking through VPN…" else if(exit==null) "No verified exit; try Refresh." else "Approximate IP location · GeoJS / ipify",style=MaterialTheme.typography.labelSmall)
                if(serverIp!=null) Text("Relay: ${serverCountry ?: "Unknown"} · $serverIp",style=MaterialTheme.typography.labelSmall)
            } else Text("Country, city and public IP appear after connecting.",style=MaterialTheme.typography.bodySmall)
        }
    }
}
