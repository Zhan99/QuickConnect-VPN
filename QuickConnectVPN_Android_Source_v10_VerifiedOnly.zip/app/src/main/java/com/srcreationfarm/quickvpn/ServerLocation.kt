package com.srcreationfarm.quickvpn

data class ServerLocation(
    val id: String,
    val countryName: String,
    val countryCode: String,
    val isoCode: String,
    val virtualIp: String,
    var proxyHost: String = "",
    var proxyPort: Int = 0,
    var proxyType: String = "SOCKS5",
    var signalLevel: Int = 2,
    var latencyMs: Int = 85
)
