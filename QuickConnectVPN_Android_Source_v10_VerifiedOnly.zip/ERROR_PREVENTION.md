# Permanent Error Prevention Log - SR Creation Farm

- **Chrome `ERR_EMPTY_RESPONSE` & Non-Working Country Listing**:
  - **Root Cause:** Modern Chrome sends ~1,600+ byte TLS ClientHello packets (with post-quantum key shares), which weak HTTP proxies drop with `ERR_EMPTY_RESPONSE` even if a tiny `HEAD` request passed. Additionally, listing 81 countries included regions with zero active public nodes.
  - **Affected Files:** `ServerRepository.kt`, `LocalProxyBridge.kt`, `MainActivity.kt`
  - **Correct Solution:** Updated `verifyFullDataTlsTunnel()` to test with a 1,600-byte TLS GET payload, added automatic 3-node failover per connection inside `LocalProxyBridge.kt`, and added `discoverWorkingCountries()` in `MainActivity.kt` to dynamically hide any country without an active, verified server.
  - **Verification Status:** Verified all Kotlin/XML syntax and ZIP archive integrity.
