# Permanent Error Prevention Log - SR Creation Farm

1. **VPN Auto-Disconnect & Crash on Connect (`QuickVpnService.kt`)**:
   - **Root Cause:** `VpnService.Builder` routed DNS traffic (`1.1.1.1`/`8.8.8.8`) to the TUN `ParcelFileDescriptor` without an active packet-reading thread or `protect(DatagramSocket)` DNS forwarder, causing the TUN buffer to stall and Android/MIUI to terminate the service. Also lacked `FOREGROUND_SERVICE_TYPE_SPECIAL_USE` in `startForeground()` on Android 14+ (API 34/35).
   - **Correct Solution:** Added a real IPv4 UDP DNS packet reader/forwarder thread (`QuickVpnTunnelLoop`) using `protect(DatagramSocket)`, Android 14+ `startForegroundCompat(..., ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)`, `PARTIAL_WAKE_LOCK`, `android:stopWithTask="false"`, and `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`.
   - **Verification Status:** Verified all Kotlin/XML syntax and ZIP archive integrity.
