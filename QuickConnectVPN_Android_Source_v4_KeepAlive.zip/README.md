# QuickConnect VPN (v1.1.0 - Tunnel Keep-Alive & DNS Packet Forwarder)

Developed by **Shahriar Rahman** | **SR Creation Farm**
- YouTube: https://www.youtube.com/@SRCreation-farm
- Facebook: https://fb.com/srcreation.farm
