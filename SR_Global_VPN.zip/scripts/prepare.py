import pathlib, re, shutil, sys, xml.etree.ElementTree as ET
root=pathlib.Path(sys.argv[1]); base=pathlib.Path(__file__).resolve().parents[1]
app=root/'app'; src=app/'src/main'; pkg=src/'java/com/payaq/opengatevpn'
def edit(p,a,b):
    t=p.read_text(); assert a in t, f'Upstream changed: {p}: {a}'; p.write_text(t.replace(a,b,1))
edit(app/'build.gradle.kts','applicationId = "com.payaq.opengatevpn"','applicationId = "com.srcreationfarm.globalvpn"')
m=src/'AndroidManifest.xml'
edit(m,'android:name=".MainActivity"','android:name="com.payaq.opengatevpn.MainActivity"')
edit(m,'</application>','<activity android:name="com.payaq.opengatevpn.SrToolsActivity" android:exported="false" />\n</application>')
p=pkg/'MainActivity.kt'
edit(p,'import android.content.Intent','''import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier''')
t=p.read_text(); pattern=r'(OpenGateVPNTheme\s*\{\s*)(MainScreen\s*\(\s*viewModel\s*=\s*viewModel,\s*onConnectClicked\s*=\s*::checkPermissionAndConnect\s*\))'
t,n=re.subn(pattern,r'''\1Column(Modifier.fillMaxSize()) {
 TextButton(onClick = { startActivity(Intent(this@MainActivity, SrToolsActivity::class.java)) }, modifier = Modifier.fillMaxWidth().statusBarsPadding()) { Text("IP check · Tools · About SR") }
 Box(Modifier.weight(1f)) { \2 }
}''',t,count=1); assert n==1,'MainActivity anchor changed'; p.write_text(t)
for p in pkg.rglob('*.kt'):
    t=p.read_text(); u=t.replace('"OpenGate VPN"','"SR Global VPN"').replace('"OpenGate"','"SR Global VPN"');
    if u!=t: p.write_text(u)
for p in (src/'res').glob('values*/strings.xml'):
    t=p.read_text(); u=re.sub(r'(<string\s+name="app_name"[^>]*>).*?(</string>)',r'\1SR Global VPN\2',t,flags=re.S)
    if t!=u: p.write_text(u)
shutil.copytree(base/'overlay',root,dirs_exist_ok=True); ET.parse(m)
print('SR overlay applied')
