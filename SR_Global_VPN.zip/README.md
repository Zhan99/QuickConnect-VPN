# SR Global VPN — Android build kit

This ZIP is a source overlay and build recipe, not a fully vendored Android Studio project. GitHub Actions fetches the GPL-3.0 OpenGateVPN Android client (including its OpenVPN engine), applies the SR source files, compiles a debug-signed APK and uploads the assembled source. No separate VPN app is intended to be necessary. The upstream ref defaults to master; set repository variable OPENGATE_REF to a reviewed commit hash to pin builds. The fetched commit is recorded in the artifact.

## Build
1. Extract ZIP and upload its contents at the root of a GitHub repository, including scripts/, overlay/ and .github/workflows/build.yml. For browser upload, create the workflow separately at that exact path using the provided build.yml.
2. Actions → Build SR Global VPN → Run workflow (or push main/master).
3. After a successful run, download artifact SR_Global_VPN and extract it. Install SR_Global_VPN.apk. The artifact also contains assembled source tar.gz and package/signature checks.
4. Debug signing is for testing. New CI debug keys may prevent updating an existing APK. Configure a persistent private signing key before distributing updates or uninstall old test APK (loses settings).

## Features and limitations
Upstream documents VPN Gate HTTPS server directory, country filters, Smart Connect/ranking, full-device OpenVPN TCP/UDP, live byte counters, recovery/retries, connection logs and refresh. SR overlay adds package ID, app branding and shield icon, developer page and social links, manual public IPv4/HTTPS comparison, download speed test, Android VPN settings link, and light/dark theme for tools only. Android 7+ ARM phones according to upstream. No ads or accounts added. No fake server list. Availability depends on real volunteer relays.

Not implemented: favorite servers, arbitrary custom .ovpn import, split tunneling UI, independent DNS/IPv6 leak prevention or testing, automatic server switch based on IP test failure, full-app theme switching, upload benchmark, guaranteed kill switch. Android Always-on/lockdown only if supported. The underlying client and engine were not independently compiled or tested here.

## Test on a phone
- Open tools while disconnected and run IP check to save baseline; connect to an available country and grant Android VPN permission; check IP again. Confirm changed IP and HTTPS success. Try browser and other apps.
- Refresh servers, switch server, test Wi-Fi/mobile network transitions, reconnect and disconnect. Check foreground notification. Verify DNS and IPv6 independently. Test lockdown on your device before relying on it.
- VPN Gate volunteers may log connection information. Avoid sensitive activity. IP check contacts ipify; speed test contacts Cloudflare. Other apps may reject VPN IPs.
- The current environment lacks network access from shell, Android SDK and Gradle. APK compilation and device tests were not performed. Workflow uses SDK 37 and the upstream Gradle wrapper as specified by upstream. If a build fails, inspect the first actual SDK/Gradle error and upstream commit.

## Attribution and licensing
Original project https://github.com/IyedAmiri/OpenGateVPN — GPL-3.0; engine derived from vpnLib and OpenVPN for Android. Preserve upstream copyright and notices. SR modifications are offered under GPL-3.0. Before distributing, ensure all corresponding source for included native binaries is provided under the applicable licenses. VPN Gate https://www.vpngate.net/en/ ; logging https://www.vpngate.net/en/about_abuse.aspx .
