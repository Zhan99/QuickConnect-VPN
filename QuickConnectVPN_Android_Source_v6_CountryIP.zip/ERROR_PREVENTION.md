# Permanent Error Prevention Log - SR Creation Farm

1. **Public IP Address Not Changing to Selected Country**:
   - **Root Cause:** Previous versions only routed DNS queries (`1.1.1.1`/`8.8.8.8`) through `VpnService` without routing TCP/HTTP/HTTPS browser traffic through a remote server in the selected country, leaving the device's public IP on the local ISP (Bangladesh).
   - **Correct Solution:** Added `ServerRepository.kt` to fetch and TCP-verify live country-filtered HTTP/SOCKS5 relay nodes for all 15 ISO country codes, `LocalProxyBridge.kt` to bridge local HTTP CONNECT & SOCKS5 streams via `VpnService.protect()`, and `VpnService.Builder.setHttpProxy(ProxyInfo.buildDirectProxy("127.0.0.1", bridgePort))` so browser and app traffic exits through the selected country's real IP address.
   - **Verification Status:** Verified all Kotlin/XML syntax and ZIP archive integrity.
