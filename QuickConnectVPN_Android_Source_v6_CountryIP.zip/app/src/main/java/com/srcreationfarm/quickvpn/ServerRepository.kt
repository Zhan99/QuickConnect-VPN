package com.srcreationfarm.quickvpn

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object ServerRepository {

    data class ProxyNode(
        val host: String,
        val port: Int,
        val type: String,
        val latencyMs: Int
    )

    private val nodePool = mutableMapOf<String, MutableList<ProxyNode>>()

    fun getPoolForCountry(isoCode: String): List<ProxyNode> {
        return synchronized(nodePool) {
            nodePool[isoCode]?.toList() ?: emptyList()
        }
    }

    /**
     * Fetches live public HTTP CONNECT / SOCKS5 proxy nodes filtered by exact ISO country code
     * and verifies TCP reachability so traffic actually exits through that country's IP address!
     */
    fun fetchAndVerifyNodeForCountry(
        isoCode: String,
        onResult: (ProxyNode?) -> Unit
    ) {
        Thread {
            // 1. Check cached verified nodes first
            val cached = getPoolForCountry(isoCode)
            for (node in cached) {
                val rtt = testTcpLatency(node.host, node.port, 1800)
                if (rtt > 0) {
                    onResult(node.copy(latencyMs = rtt))
                    return@Thread
                }
            }

            // 2. Fetch fresh country-specific nodes from ProxyScrape v2 & GeoNode APIs
            val candidates = mutableListOf<Pair<String, Pair<Int, String>>>()

            try {
                val urlStr =
                    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=3000&country=$isoCode&ssl=yes&anonymity=elite"
                val text = httpGet(urlStr, 5000)
                text.lines().forEach { line ->
                    val parts = line.trim().split(":")
                    if (parts.size == 2) {
                        val port = parts[1].toIntOrNull()
                        if (port != null && port in 1..65535) {
                            candidates.add(parts[0] to (port to "HTTP"))
                        }
                    }
                }
            } catch (_: Exception) {
            }

            if (candidates.size < 5) {
                try {
                    val urlStr =
                        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=3000&country=$isoCode"
                    val text = httpGet(urlStr, 5000)
                    text.lines().forEach { line ->
                        val parts = line.trim().split(":")
                        if (parts.size == 2) {
                            val port = parts[1].toIntOrNull()
                            if (port != null && port in 1..65535) {
                                candidates.add(parts[0] to (port to "SOCKS5"))
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }

            if (candidates.isEmpty()) {
                try {
                    val geoUrl =
                        "https://proxylist.geonode.com/api/proxy-list?country=$isoCode&limit=15&page=1&sort_by=lastChecked&sort_type=desc&protocols=http%2Csocks5"
                    val jsonStr = httpGet(geoUrl, 5000)
                    val root = JSONObject(jsonStr)
                    val data = root.optJSONArray("data")
                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val item = data.getJSONObject(i)
                            val ip = item.optString("ip")
                            val port = item.optString("port").toIntOrNull() ?: 0
                            val protocols = item.optJSONArray("protocols")
                            val proto = if (protocols != null && protocols.length() > 0) {
                                protocols.getString(0).uppercase()
                            } else {
                                "HTTP"
                            }
                            if (ip.isNotEmpty() && port > 0) {
                                candidates.add(ip to (port to if (proto.contains("SOCKS")) "SOCKS5" else "HTTP"))
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }

            if (candidates.isEmpty()) {
                onResult(null)
                return@Thread
            }

            // 3. Test up to 20 candidates concurrently and pick the fastest live node in that country
            val subset = candidates.take(20)
            val executor = Executors.newFixedThreadPool(8)
            val verified = java.util.Collections.synchronizedList(mutableListOf<ProxyNode>())

            for ((host, portAndType) in subset) {
                executor.submit {
                    val (port, type) = portAndType
                    val rtt = testTcpLatency(host, port, 2200)
                    if (rtt > 0) {
                        verified.add(ProxyNode(host, port, type, rtt))
                    }
                }
            }
            executor.shutdown()
            try {
                executor.awaitTermination(5, TimeUnit.SECONDS)
            } catch (_: Exception) {
            }

            val sorted = verified.sortedBy { it.latencyMs }
            if (sorted.isNotEmpty()) {
                synchronized(nodePool) {
                    nodePool[isoCode] = sorted.toMutableList()
                }
                onResult(sorted.first())
            } else {
                onResult(null)
            }
        }.start()
    }

    fun testTcpLatency(host: String, port: Int, timeoutMs: Int): Int {
        return try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            (System.currentTimeMillis() - start).toInt().coerceAtLeast(1)
        } catch (_: Exception) {
            -1
        }
    }

    private fun httpGet(urlStr: String, timeoutMs: Int): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            requestMethod = "GET"
            setRequestProperty("User-Agent", "QuickConnectVPN/1.3.0")
        }
        return try {
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            } else {
                ""
            }
        } finally {
            conn.disconnect()
        }
    }
}
