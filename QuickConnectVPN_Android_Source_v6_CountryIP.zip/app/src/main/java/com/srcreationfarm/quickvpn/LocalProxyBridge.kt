package com.srcreationfarm.quickvpn

import android.net.VpnService
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class LocalProxyBridge(
    private val vpnService: VpnService,
    private val remoteHost: String,
    private val remotePort: Int,
    private val remoteType: String // "HTTP" or "SOCKS5"
) {
    private var serverSocket: ServerSocket? = null
    private var acceptThread: Thread? = null
    private var executor: ExecutorService? = null
    private val running = AtomicBoolean(false)

    var localPort: Int = 0
        private set

    fun start(): Int {
        stop()
        val ss = ServerSocket()
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0))
        localPort = ss.localPort
        serverSocket = ss
        running.set(true)
        executor = Executors.newCachedThreadPool()

        acceptThread = Thread({
            while (running.get() && !Thread.currentThread().isInterrupted) {
                try {
                    val client = ss.accept()
                    executor?.submit { handleClient(client) }
                } catch (_: Exception) {
                    if (!running.get()) break
                }
            }
        }, "QuickVpnProxyBridge").apply {
            isDaemon = true
            start()
        }
        return localPort
    }

    fun stop() {
        running.set(false)
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
        try {
            acceptThread?.interrupt()
        } catch (_: Exception) {
        }
        acceptThread = null
        try {
            executor?.shutdownNow()
        } catch (_: Exception) {
        }
        executor = null
    }

    private fun handleClient(client: Socket) {
        var upstream: Socket? = null
        try {
            client.soTimeout = 15000
            val clientIn = client.getInputStream()
            val clientOut = client.getOutputStream()

            // Read initial HTTP request headers from local browser/app
            val headerBytes = readHttpHeaders(clientIn)
            if (headerBytes.isEmpty()) {
                client.close()
                return
            }

            val headerText = String(headerBytes, StandardCharsets.ISO_8859_1)
            val firstLine = headerText.lineSequence().firstOrNull() ?: ""
            val parts = firstLine.split(" ")
            if (parts.size < 2) {
                client.close()
                return
            }

            val method = parts[0].uppercase()
            val target = parts[1]

            // Connect to selected country's remote proxy via VpnService.protect()
            upstream = Socket()
            if (!vpnService.protect(upstream)) {
                client.close()
                return
            }
            upstream.soTimeout = 15000
            upstream.connect(InetSocketAddress(remoteHost, remotePort), 6000)
            val upIn = upstream.getInputStream()
            val upOut = upstream.getOutputStream()

            if (remoteType == "SOCKS5") {
                // Parse target host & port from CONNECT host:port or http://host:port/path
                val (dstHost, dstPort) = extractHostPort(method, target, headerText)
                if (!performSocks5Handshake(upIn, upOut, dstHost, dstPort)) {
                    client.close()
                    upstream.close()
                    return
                }

                if (method == "CONNECT") {
                    val okResp = "HTTP/1.1 200 Connection Established\r\nProxy-Agent: QuickConnectVPN\r\n\r\n"
                    clientOut.write(okResp.toByteArray(StandardCharsets.ISO_8859_1))
                    clientOut.flush()
                } else {
                    upOut.write(headerBytes)
                    upOut.flush()
                }
            } else {
                // Upstream HTTP / HTTPS CONNECT proxy: forward request directly
                upOut.write(headerBytes)
                upOut.flush()
            }

            // Bidirectional stream relay between local client and remote country proxy
            val t1 = Thread {
                relayStream(clientIn, upOut)
                try { upstream.shutdownOutput() } catch (_: Exception) {}
            }
            val t2 = Thread {
                relayStream(upIn, clientOut)
                try { client.shutdownOutput() } catch (_: Exception) {}
            }
            t1.start()
            t2.start()
            t1.join()
            t2.join()
        } catch (_: Exception) {
        } finally {
            try { client.close() } catch (_: Exception) {}
            try { upstream?.close() } catch (_: Exception) {}
        }
    }

    private fun readHttpHeaders(input: InputStream): ByteArray {
        val buf = ArrayList<Byte>(1024)
        var state = 0
        while (buf.size < 32768) {
            val b = input.read()
            if (b == -1) break
            buf.add(b.toByte())
            state = when {
                state == 0 && b == '\r'.code -> 1
                state == 1 && b == '\n'.code -> 2
                state == 2 && b == '\r'.code -> 3
                state == 3 && b == '\n'.code -> 4
                b == '\r'.code -> 1
                else -> 0
            }
            if (state == 4) break
        }
        val arr = ByteArray(buf.size)
        for (i in buf.indices) arr[i] = buf[i]
        return arr
    }

    private fun extractHostPort(method: String, target: String, headers: String): Pair<String, Int> {
        if (method == "CONNECT") {
            val hp = target.split(":")
            val h = hp[0]
            val p = hp.getOrNull(1)?.toIntOrNull() ?: 443
            return h to p
        }
        val hostHeader = headers.lineSequence()
            .firstOrNull { it.startsWith("Host:", ignoreCase = true) }
            ?.substringAfter(":")?.trim() ?: ""
        if (hostHeader.isNotEmpty()) {
            val hp = hostHeader.split(":")
            return hp[0] to (hp.getOrNull(1)?.toIntOrNull() ?: 80)
        }
        val clean = target.removePrefix("http://").removePrefix("https://").substringBefore("/")
        val hp = clean.split(":")
        return hp[0] to (hp.getOrNull(1)?.toIntOrNull() ?: 80)
    }

    private fun performSocks5Handshake(
        upIn: InputStream,
        upOut: OutputStream,
        dstHost: String,
        dstPort: Int
    ): Boolean {
        // Greeting: SOCKS5, 1 auth method (No Auth 0x00)
        upOut.write(byteArrayOf(0x05, 0x01, 0x00))
        upOut.flush()
        val greetResp = ByteArray(2)
        if (readExact(upIn, greetResp) != 2 || greetResp[0] != 0x05.toByte() || greetResp[1] != 0x00.toByte()) {
            return false
        }

        // CONNECT request with domain name (0x03)
        val hostBytes = dstHost.toByteArray(StandardCharsets.UTF_8)
        if (hostBytes.size > 255) return false
        val req = ByteArray(7 + hostBytes.size)
        req[0] = 0x05
        req[1] = 0x01 // CONNECT
        req[2] = 0x00 // RSV
        req[3] = 0x03 // DOMAINNAME
        req[4] = hostBytes.size.toByte()
        System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
        req[5 + hostBytes.size] = ((dstPort shr 8) and 0xFF).toByte()
        req[6 + hostBytes.size] = (dstPort and 0xFF).toByte()
        upOut.write(req)
        upOut.flush()

        val head = ByteArray(4)
        if (readExact(upIn, head) != 4 || head[1] != 0x00.toByte()) {
            return false
        }
        val skipLen = when (head[3].toInt() and 0xFF) {
            0x01 -> 4 + 2
            0x04 -> 16 + 2
            0x03 -> {
                val lenByte = upIn.read()
                if (lenByte < 0) return false
                lenByte + 2
            }
            else -> return false
        }
        val discard = ByteArray(skipLen)
        return readExact(upIn, discard) == skipLen
    }

    private fun readExact(input: InputStream, buf: ByteArray): Int {
        var offset = 0
        while (offset < buf.size) {
            val n = input.read(buf, offset, buf.size - offset)
            if (n <= 0) return offset
            offset += n
        }
        return offset
    }

    private fun relayStream(input: InputStream, output: OutputStream) {
        val buffer = ByteArray(16384)
        try {
            while (running.get()) {
                val count = input.read(buffer)
                if (count == -1) break
                if (count > 0) {
                    output.write(buffer, 0, count)
                    output.flush()
                }
            }
        } catch (_: Exception) {
        }
    }
}
