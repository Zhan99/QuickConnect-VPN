package com.srcreationfarm.quickvpn

data class ServerLocation(
    val id: String,
    val countryName: String,
    val countryCode: String,
    val dnsPrimary: String,
    val dnsSecondary: String,
    val virtualIp: String,
    var signalLevel: Int,
    var latencyMs: Int
)
