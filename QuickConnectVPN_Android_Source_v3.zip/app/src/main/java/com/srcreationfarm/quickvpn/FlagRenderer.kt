package com.srcreationfarm.quickvpn

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.cos
import kotlin.math.sin

object FlagRenderer {

    private val cache = mutableMapOf<String, Bitmap>()

    fun getFlagBitmap(countryCode: String): Bitmap {
        cache[countryCode]?.let { return it }

        val width = 140
        val height = 96
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val w = width.toFloat()
        val h = height.toFloat()

        when (countryCode) {
            "SG" -> {
                paint.color = Color.parseColor("#EF3340")
                canvas.drawRect(0f, 0f, w, h / 2f, paint)
                paint.color = Color.WHITE
                canvas.drawRect(0f, h / 2f, w, h, paint)
                canvas.drawCircle(w * 0.23f, h * 0.25f, h * 0.16f, paint)
                paint.color = Color.parseColor("#EF3340")
                canvas.drawCircle(w * 0.28f, h * 0.25f, h * 0.15f, paint)
                paint.color = Color.WHITE
                val starAngles = listOf(0.0, 72.0, 144.0, 216.0, 288.0)
                for (deg in starAngles) {
                    val rad = Math.toRadians(deg - 90.0)
                    val sx = w * 0.33f + (h * 0.08f * cos(rad)).toFloat()
                    val sy = h * 0.25f + (h * 0.08f * sin(rad)).toFloat()
                    canvas.drawCircle(sx, sy, 2.2f, paint)
                }
            }
            "IN" -> {
                paint.color = Color.parseColor("#FF9933")
                canvas.drawRect(0f, 0f, w, h / 3f, paint)
                paint.color = Color.WHITE
                canvas.drawRect(0f, h / 3f, w, h * 2f / 3f, paint)
                paint.color = Color.parseColor("#138808")
                canvas.drawRect(0f, h * 2f / 3f, w, h, paint)
                paint.color = Color.parseColor("#000080")
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2.5f
                canvas.drawCircle(w / 2f, h / 2f, h * 0.12f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(w / 2f, h / 2f, 2.5f, paint)
            }
            "KR" -> {
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w, h, paint)
                val cx = w / 2f
                val cy = h / 2f
                val r = h * 0.22f
                paint.color = Color.parseColor("#CD2E3A")
                canvas.drawArc(cx - r, cy - r, cx + r, cy + r, 180f, 180f, true, paint)
                paint.color = Color.parseColor("#0047A0")
                canvas.drawArc(cx - r, cy - r, cx + r, cy + r, 0f, 180f, true, paint)
                paint.color = Color.parseColor("#CD2E3A")
                canvas.drawCircle(cx - r / 2f, cy, r / 2f, paint)
                paint.color = Color.parseColor("#0047A0")
                canvas.drawCircle(cx + r / 2f, cy, r / 2f, paint)
                paint.color = Color.BLACK
                paint.strokeWidth = 3f
                canvas.drawLine(w * 0.20f, h * 0.20f, w * 0.30f, h * 0.30f, paint)
                canvas.drawLine(w * 0.70f, h * 0.30f, w * 0.80f, h * 0.20f, paint)
                canvas.drawLine(w * 0.20f, h * 0.80f, w * 0.30f, h * 0.70f, paint)
                canvas.drawLine(w * 0.70f, h * 0.70f, w * 0.80f, h * 0.80f, paint)
            }
            "AU" -> {
                paint.color = Color.parseColor("#00008B")
                canvas.drawRect(0f, 0f, w, h, paint)
                drawUnionJack(canvas, w / 2f, h / 2f, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.25f, h * 0.75f, 5.5f, paint)
                canvas.drawCircle(w * 0.75f, h * 0.22f, 3.5f, paint)
                canvas.drawCircle(w * 0.68f, h * 0.45f, 3.5f, paint)
                canvas.drawCircle(w * 0.83f, h * 0.42f, 3.5f, paint)
                canvas.drawCircle(w * 0.75f, h * 0.78f, 4.0f, paint)
            }
            "JP" -> {
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#BC002D")
                canvas.drawCircle(w / 2f, h / 2f, h * 0.28f, paint)
            }
            "US_EAST", "US_WEST" -> {
                val stripeH = h / 13f
                for (i in 0 until 13) {
                    paint.color = if (i % 2 == 0) Color.parseColor("#B22234") else Color.WHITE
                    canvas.drawRect(0f, i * stripeH, w, (i + 1) * stripeH, paint)
                }
                paint.color = Color.parseColor("#3C3B6E")
                canvas.drawRect(0f, 0f, w * 0.42f, stripeH * 7f, paint)
                paint.color = Color.WHITE
                for (row in 0 until 4) {
                    for (col in 0 until 5) {
                        canvas.drawCircle(
                            w * 0.05f + col * (w * 0.08f),
                            stripeH * 1.1f + row * (stripeH * 1.6f),
                            1.8f,
                            paint
                        )
                    }
                }
            }
            "CA" -> {
                paint.color = Color.parseColor("#D80621")
                canvas.drawRect(0f, 0f, w * 0.26f, h, paint)
                canvas.drawRect(w * 0.74f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(w * 0.26f, 0f, w * 0.74f, h, paint)
                paint.color = Color.parseColor("#D80621")
                val leaf = Path().apply {
                    moveTo(w * 0.50f, h * 0.20f)
                    lineTo(w * 0.56f, h * 0.36f)
                    lineTo(w * 0.65f, h * 0.34f)
                    lineTo(w * 0.60f, h * 0.52f)
                    lineTo(w * 0.66f, h * 0.56f)
                    lineTo(w * 0.52f, h * 0.66f)
                    lineTo(w * 0.52f, h * 0.80f)
                    lineTo(w * 0.48f, h * 0.80f)
                    lineTo(w * 0.48f, h * 0.66f)
                    lineTo(w * 0.34f, h * 0.56f)
                    lineTo(w * 0.40f, h * 0.52f)
                    lineTo(w * 0.35f, h * 0.34f)
                    lineTo(w * 0.44f, h * 0.36f)
                    close()
                }
                canvas.drawPath(leaf, paint)
            }
            "DE" -> {
                paint.color = Color.parseColor("#111111")
                canvas.drawRect(0f, 0f, w, h / 3f, paint)
                paint.color = Color.parseColor("#DD0000")
                canvas.drawRect(0f, h / 3f, w, h * 2f / 3f, paint)
                paint.color = Color.parseColor("#FFCE00")
                canvas.drawRect(0f, h * 2f / 3f, w, h, paint)
            }
            "GB" -> {
                drawUnionJack(canvas, w, h, paint)
            }
            "NL" -> {
                paint.color = Color.parseColor("#AE1C28")
                canvas.drawRect(0f, 0f, w, h / 3f, paint)
                paint.color = Color.WHITE
                canvas.drawRect(0f, h / 3f, w, h * 2f / 3f, paint)
                paint.color = Color.parseColor("#21468B")
                canvas.drawRect(0f, h * 2f / 3f, w, h, paint)
            }
            "ES" -> {
                paint.color = Color.parseColor("#AA151B")
                canvas.drawRect(0f, 0f, w, h * 0.25f, paint)
                canvas.drawRect(0f, h * 0.75f, w, h, paint)
                paint.color = Color.parseColor("#F1BF00")
                canvas.drawRect(0f, h * 0.25f, w, h * 0.75f, paint)
                paint.color = Color.parseColor("#AA151B")
                canvas.drawRect(w * 0.26f, h * 0.38f, w * 0.36f, h * 0.62f, paint)
            }
            "FR" -> {
                paint.color = Color.parseColor("#002395")
                canvas.drawRect(0f, 0f, w / 3f, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(w / 3f, 0f, w * 2f / 3f, h, paint)
                paint.color = Color.parseColor("#ED2939")
                canvas.drawRect(w * 2f / 3f, 0f, w, h, paint)
            }
            "IT" -> {
                paint.color = Color.parseColor("#009246")
                canvas.drawRect(0f, 0f, w / 3f, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(w / 3f, 0f, w * 2f / 3f, h, paint)
                paint.color = Color.parseColor("#CE2B37")
                canvas.drawRect(w * 2f / 3f, 0f, w, h, paint)
            }
            "SE" -> {
                paint.color = Color.parseColor("#006AA7")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#FECC02")
                canvas.drawRect(w * 0.31f, 0f, w * 0.44f, h, paint)
                canvas.drawRect(0f, h * 0.40f, w, h * 0.60f, paint)
            }
        }

        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#26000000")
        paint.strokeWidth = 2f
        canvas.drawRect(0f, 0f, w, h, paint)

        cache[countryCode] = bmp
        return bmp
    }

    private fun drawUnionJack(canvas: Canvas, w: Float, h: Float, paint: Paint) {
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#012169")
        canvas.drawRect(0f, 0f, w, h, paint)

        paint.color = Color.WHITE
        paint.strokeWidth = h * 0.16f
        canvas.drawLine(0f, 0f, w, h, paint)
        canvas.drawLine(w, 0f, 0f, h, paint)

        paint.color = Color.parseColor("#C8102E")
        paint.strokeWidth = h * 0.08f
        canvas.drawLine(0f, 0f, w, h, paint)
        canvas.drawLine(w, 0f, 0f, h, paint)

        paint.color = Color.WHITE
        canvas.drawRect(w * 0.40f, 0f, w * 0.60f, h, paint)
        canvas.drawRect(0f, h * 0.36f, w, h * 0.64f, paint)

        paint.color = Color.parseColor("#C8102E")
        canvas.drawRect(w * 0.44f, 0f, w * 0.56f, h, paint)
        canvas.drawRect(0f, h * 0.42f, w, h * 0.58f, paint)
    }
}
