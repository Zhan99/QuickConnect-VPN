package com.srcreationfarm.quickvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat

class QuickVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_CONNECT
        if (action == ACTION_DISCONNECT) {
            stopVpnTunnel()
            return START_NOT_STICKY
        }

        val countryName = intent?.getStringExtra(EXTRA_COUNTRY_NAME) ?: "US East"
        val dnsPrimary = intent?.getStringExtra(EXTRA_DNS_PRIMARY) ?: "1.1.1.1"
        val dnsSecondary = intent?.getStringExtra(EXTRA_DNS_SECONDARY) ?: "1.0.0.1"
        val virtualIp = intent?.getStringExtra(EXTRA_VIRTUAL_IP) ?: "10.8.0.2"

        startForeground(NOTIFICATION_ID, buildNotification(countryName, dnsPrimary))
        establishTunnel(countryName, virtualIp, dnsPrimary, dnsSecondary)
        return START_STICKY
    }

    private fun establishTunnel(
        countryName: String,
        virtualIp: String,
        dnsPrimary: String,
        dnsSecondary: String
    ) {
        try {
            vpnInterface?.close()
            val builder = Builder()
                .setSession("QuickConnect VPN - $countryName")
                .setMtu(1500)
                .addAddress(virtualIp, 24)
                .addDnsServer(dnsPrimary)
                .addDnsServer(dnsSecondary)
                .addRoute(dnsPrimary, 32)
                .addRoute(dnsSecondary, 32)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            vpnInterface = builder.establish()
            isConnected = vpnInterface != null
            activeServerName = if (isConnected) countryName else ""
            broadcastState()
        } catch (e: Exception) {
            isConnected = false
            activeServerName = ""
            broadcastState()
            stopSelf()
        }
    }

    private fun stopVpnTunnel() {
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        } finally {
            vpnInterface = null
            isConnected = false
            activeServerName = ""
            broadcastState()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun buildNotification(countryName: String, dnsPrimary: String): Notification {
        createNotificationChannel()
        val pendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            pendingFlags
        )

        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, QuickVpnService::class.java).apply { action = ACTION_DISCONNECT },
            pendingFlags
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_vpn_key)
            .setContentTitle("QuickVPN • Connected ($countryName)")
            .setContentText("Encrypted DNS Tunnel ($dnsPrimary) • SR Creation Farm")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Disconnect", disconnectIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "QuickConnect VPN Tunnel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays active VPN connection status"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun broadcastState() {
        val intent = Intent(ACTION_VPN_STATE_CHANGED).apply {
            setPackage(packageName)
            putExtra(EXTRA_IS_CONNECTED, isConnected)
            putExtra(EXTRA_COUNTRY_NAME, activeServerName)
        }
        sendBroadcast(intent)
    }

    override fun onDestroy() {
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }
        vpnInterface = null
        isConnected = false
        activeServerName = ""
        super.onDestroy()
    }

    companion object {
        const val ACTION_CONNECT = "com.srcreationfarm.quickvpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.srcreationfarm.quickvpn.ACTION_DISCONNECT"
        const val ACTION_VPN_STATE_CHANGED = "com.srcreationfarm.quickvpn.STATE_CHANGED"

        const val EXTRA_COUNTRY_NAME = "extra_country_name"
        const val EXTRA_DNS_PRIMARY = "extra_dns_primary"
        const val EXTRA_DNS_SECONDARY = "extra_dns_secondary"
        const val EXTRA_VIRTUAL_IP = "extra_virtual_ip"
        const val EXTRA_IS_CONNECTED = "extra_is_connected"

        private const val CHANNEL_ID = "quickvpn_tunnel_channel"
        private const val NOTIFICATION_ID = 101

        @Volatile
        var isConnected: Boolean = false

        @Volatile
        var activeServerName: String = ""
    }
}
