# Permanent Error Prevention Log - SR Creation Farm

1. **Maven Central Artifact Resolution Failure (`generateDebugLintReportModel`)**:
   - **Error Message:** `Could not resolve all files for configuration ':app:debugRuntimeClasspath'. Could not find error_prone_annotations-2.15.0.jar / listenablefuture-1.0.jar`
   - **Root Cause:** GitHub Actions Ubuntu 24.04 runners experience intermittent IPv6 connection drops against `repo.maven.apache.org`, and legacy `listenablefuture:1.0` transitive resolution conflicts without explicit IPv4 preference and fallback Maven Central mirror (`repo1.maven.org`).
   - **Affected Files:** `gradle.properties`, `settings.gradle.kts`, `app/build.gradle.kts`, `.github/workflows/build.yml`
   - **Correct Solution:** Enforced `-Djava.net.preferIPv4Stack=true` in both `gradle.properties` and `build.yml` (`GRADLE_OPTS`), added `https://repo1.maven.org/maven2/` fallback repository, declared `com.google.guava:listenablefuture:9999.0-empty-to-avoid-conflict-with-guava` and `error_prone_annotations:2.28.0`, and suppressed the AGP 8.5.2 `compileSdk=35` warning via `android.suppressUnsupportedCompileSdk=35`.
   - **Verification Status:** Verified XML/Kotlin syntax and ZIP archive integrity.
