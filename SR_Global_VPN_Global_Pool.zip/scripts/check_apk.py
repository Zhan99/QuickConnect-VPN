"""Reject corrupt APKs or APKs without expected ARM VPN native payloads."""
import sys
from pathlib import PurePosixPath
from zipfile import ZipFile

with ZipFile(sys.argv[1]) as apk:
    bad = apk.testzip()
    assert bad is None, f'Corrupt APK member: {bad}'
    names = set(apk.namelist())
    assert {'AndroidManifest.xml', 'classes.dex'} <= names, 'Missing manifest or DEX'
    for abi in ('arm64-v8a', 'armeabi-v7a'):
        native = [n for n in names if n.startswith(f'lib/{abi}/') and n.endswith('.so')]
        vpn = [n for n in native if any(s in PurePosixPath(n).name.lower() for s in ('openvpn', 'ovpn'))]
        assert vpn, f'No OpenVPN native payload for {abi}'
        assert all(apk.read(n)[:4] == b'\x7fELF' for n in vpn), f'Invalid native payload for {abi}'
        print(abi, ', '.join(sorted(vpn)))
print('APK archive and ARM VPN native payload checks: OK')
