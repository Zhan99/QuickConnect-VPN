"""Validate the embedded source kit, independent of repository layout."""
import ast
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
for name in ('scripts/prepare.py', 'scripts/check_apk.py', 'README.md', 'LICENSE-SR', 'overlay/app/src/main/res/drawable/ic_opengate_logo.xml'):
    assert (root / name).is_file(), f'Missing {name}'
for path in (root / 'scripts').glob('*.py'):
    ast.parse(path.read_text(), filename=str(path))
for path in (root / 'overlay').rglob('*.xml'):
    ET.parse(path)
source = root / 'overlay/app/src/main/java/com/payaq/opengatevpn/SrToolsActivity.kt'
assert source.is_file() and 'class SrToolsActivity' in source.read_text()

for name in ("VpnGateApi.kt", "SrDirectoryPolicy.kt", "SrRollingPool.kt", "SrPoolRef.kt"):
    assert (source.parent / "data/remote" / name).is_file(), f"Missing {name}"

print('Embedded build kit structure, Python syntax, XML: OK')
