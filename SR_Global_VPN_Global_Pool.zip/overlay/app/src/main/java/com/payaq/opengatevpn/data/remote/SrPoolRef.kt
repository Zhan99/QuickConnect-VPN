package com.payaq.opengatevpn.data.remote

/** Internal descriptor, never passed into OpenVPN until resolved and verified. */
internal data class SrPoolRef(val commit:String, val hash:String, val size:Int, val fileHash:String, val fileSize:Int) {
    fun encode() = "srpool:$commit:$hash:$size:$fileHash:$fileSize"
    val path get() = "pool/configs/$hash.json"
    companion object {
        fun isReference(value:String) = value.startsWith("srpool:")
        fun decode(value:String):SrPoolRef {
            val p=value.split(':'); require(p.size==6 && p[0]=="srpool")
            val commit=p[1]; val hash=p[2]; val fileHash=p[4]
            require(Regex("[a-f0-9]{40}").matches(commit))
            require(Regex("[a-f0-9]{64}").matches(hash) && Regex("[a-f0-9]{64}").matches(fileHash))
            val size=p[3].toInt(); val fileSize=p[5].toInt()
            require(size in 1..131072 && fileSize in 1..262144)
            return SrPoolRef(commit,hash,size,fileHash,fileSize)
        }
    }
}
