package com.payaq.opengatevpn

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import java.util.concurrent.Executors

class SrToolsActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var panel: LinearLayout
    private val io = Executors.newSingleThreadExecutor()
    private fun dp(n: Int) = (n*resources.displayMetrics.density).toInt()
    private fun vpnActive():Boolean {
        val cm=getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN)==true
    }
    private fun task(action:()->String) {
        output.text="Checking…"
        io.execute { val result=try {action()} catch (_:Exception) {"Network test failed. Try another server or network."}; runOnUiThread { if(!isDestroyed) output.text=result } }
    }
    private fun connection(url:String):HttpsURLConnection=(URL(url).openConnection() as HttpsURLConnection).apply { connectTimeout=10000; readTimeout=10000; useCaches=false }
    private fun checkIp():String {
        val before=vpnActive(); val c=connection("https://api.ipify.org")
        val ip=try { check(c.responseCode==200); c.inputStream.bufferedReader().use {it.readLine().trim()} } finally {c.disconnect()}
        require(ip.matches(Regex("[0-9]{1,3}(\\.[0-9]{1,3}){3}")))
        val after=vpnActive(); if(before!=after) return "Network changed during test. Retry."
        val p=getSharedPreferences("sr_diagnostics",0)
        if(!after) {p.edit().putString("baseline",ip).apply(); return "Direct network; HTTPS works. Baseline IPv4: $ip"}
        val baseline=p.getString("baseline",null)
        return when { baseline==null -> "VPN network detected; HTTPS works. Public IPv4: $ip. Disconnect and test first to establish baseline."; baseline==ip -> "VPN network detected, but IPv4 unchanged: $ip"; else -> "VPN network detected; HTTPS works and IPv4 changed.\nBefore: $baseline\nNow: $ip" }
    }
    private fun speed():String {
        val before=vpnActive(); val c=connection("https://speed.cloudflare.com/__down?bytes=2000000")
        val start=System.nanoTime(); var total=0L
        try {check(c.responseCode==200); c.inputStream.use {input-> val buf=ByteArray(16384); while(total<2000000){val n=input.read(buf); if(n<0)break; total+=n}}} finally {c.disconnect()}
        val sec=(System.nanoTime()-start)/1e9; check(total>0 && sec>0)
        if(before!=vpnActive())return "Network changed during test. Retry."
        return String.format(java.util.Locale.US,"Download: %.2f Mbps (%s; %.2f MB)",total*8/sec/1e6,if(before)"VPN" else "direct",total/1e6)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dark=getPreferences(0).getBoolean("dark",true)
        val bg=Color.parseColor(if(dark)"#071B29" else "#F1F7FA"); val fg=Color.parseColor(if(dark)"#DCEEF5" else "#102D3D")
        window.statusBarColor=bg; window.navigationBarColor=bg
        val scroll=ScrollView(this); scroll.setBackgroundColor(bg)
        panel=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(48),dp(20),dp(48))}; scroll.addView(panel); setContentView(scroll)
        fun label(s:String,size:Float=16f):TextView=TextView(this).apply {text=s;textSize=size;setTextColor(fg);setPadding(0,dp(8),0,dp(8));panel.addView(this)}
        fun button(s:String,action:()->Unit){panel.addView(Button(this).apply{text=s;isAllCaps=false;setOnClickListener{action()}},LinearLayout.LayoutParams(-1,-2))}
        label("SR GLOBAL VPN",26f);label("Connection diagnostics & settings",18f)
        output=label("Run IP check before and after connecting.")
        button("Check public IP & internet"){task{checkIp()}}
        button("Download speed test (2 MB)"){task{speed()}}
        button("Android VPN settings / Kill switch") {
            AlertDialog.Builder(this).setTitle("Android kill switch").setMessage("In Android VPN settings, select SR Global VPN and enable Always-on VPN and Block connections without VPN if supported. Otherwise a kill switch is unavailable. Disconnecting or pausing can expose direct IP without lockdown.").setPositiveButton("Open settings"){_,_->try{startActivity(Intent(Settings.ACTION_VPN_SETTINGS))}catch(_:Exception){startActivity(Intent(Settings.ACTION_SETTINGS))}}.setNegativeButton("Cancel",null).show()
        }
        button(if(dark)"Light tools theme" else "Dark tools theme"){getPreferences(0).edit().putBoolean("dark",!dark).apply();recreate()}
        label("Privacy & safety",20f);label("Directory uses VPN Gate and a recent third-party HTTPS mirror (GitHub). Mirror nodes may have gone offline; country and speed are directory reports, not tunnel tests. Public VPN Gate relays are run by third parties and may log connection data. Avoid sensitive activity. IP check contacts ipify; speed test contacts Cloudflare. No result guarantees DNS or IPv6 leak protection.")
        button("VPN Gate logging policy"){link("https://www.vpngate.net/en/about_abuse.aspx")}
        label("About developer",20f);label("Shahriar Rahman\nSR Creation Farm\n© SR Creation Farm — SR modifications\nOpenGateVPN and OpenVPN contributors retain their copyright. GPL source and notices accompany the build.\nVersion: "+packageManager.getPackageInfo(packageName,0).versionName)
        button("YouTube · SR Creation Farm"){link("https://www.youtube.com/@SRCreation-farm")}
        button("Facebook · SR Creation Farm"){link("https://fb.com/srcreation.farm")}
        button("Original open-source project"){link("https://github.com/IyedAmiri/OpenGateVPN")}
        button("Back to VPN"){finish()}
    }
    private fun link(url:String){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(_:Exception){Toast.makeText(this,"No browser available",Toast.LENGTH_SHORT).show()}}
    override fun onDestroy(){io.shutdownNow();super.onDestroy()}
}
