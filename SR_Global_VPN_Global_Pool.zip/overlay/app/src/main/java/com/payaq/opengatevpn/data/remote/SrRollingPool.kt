package com.payaq.opengatevpn.data.remote

import android.util.Base64
import com.payaq.opengatevpn.data.model.VpnServer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/** Public, content-addressed Gate rolling pool. Catalog only on refresh; profile on demand. */
internal object SrRollingPool {
    private const val REPO = "GeorgeXie2333/vpngate-list-mirror"
    private const val RAW = "https://raw.githubusercontent.com/$REPO"
    private const val DAY = 86400000L
    private val cache = object : LinkedHashMap<String,String>(16,0.75f,true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String,String>?):Boolean = size > 12
    }
    private suspend fun download(url:String, limit:Int):ByteArray = withContext(Dispatchers.IO) {
        val c=URL(url).openConnection() as HttpsURLConnection
        c.connectTimeout=4500; c.readTimeout=6000; c.instanceFollowRedirects=false; c.useCaches=false
        try {
            check(c.responseCode==200) { "Pool HTTP ${c.responseCode}" }
            val out=ByteArrayOutputStream(); val start=System.nanoTime()
            c.inputStream.use { input ->
                val buf=ByteArray(16384)
                while(true) {
                    check((System.nanoTime()-start)/1_000_000L < 15000L) { "Pool read timeout" }
                    val n=input.read(buf); if(n<0) break
                    check(out.size()+n<=limit) { "Pool size limit" }; out.write(buf,0,n)
                }
            }; out.toByteArray()
        } finally { c.disconnect() }
    }
    private suspend fun verified(commit:String,path:String,size:Int,hash:String):ByteArray {
        require(Regex("[a-f0-9]{40}").matches(commit) && Regex("[a-f0-9]{64}").matches(hash))
        require(size in 1..SrDirectoryPolicy.MAX_BYTES)
        var failure:Exception?=null
        for(url in listOf("https://cdn.jsdelivr.net/gh/$REPO@$commit/$path", "$RAW/$commit/$path")) {
            try {
                val bytes=download(url,size)
                check(bytes.size==size && SrDirectoryPolicy.sha256(bytes)==hash) { "Pool file integrity mismatch" }
                return bytes
            } catch(e:CancellationException) { throw e } catch(e:Exception) { failure=e }
        }
        throw failure ?: IllegalStateException("Pool download failed")
    }
    suspend fun fetch():List<VpnServer> {
        val index=JSONObject(download("$RAW/main/pool/latest.json",65536).toString(Charsets.UTF_8))
        val now=System.currentTimeMillis()
        check(index.getInt("schema_version")==1 && index.getString("kind")=="vpngate-pool")
        check(index.getString("source_url")=="https://www.vpngate.net/api/iphone/")
        val time=index.getString("source_fetched_at")
        check(SrDirectoryPolicy.isFresh(time,now,DAY)) { "Pool index expired" }
        val commit=index.getString("data_commit"); val count=index.getInt("server_count"); check(count in 1..5000)
        val meta=index.getJSONObject("files").getJSONObject("pool/servers.json")
        val catalog=JSONObject(verified(commit,"pool/servers.json",meta.getInt("bytes"),meta.getString("sha256")).toString(Charsets.UTF_8))
        check(catalog.getInt("schema_version")==1 && catalog.getString("kind")=="vpngate-pool")
        check(catalog.getString("source_fetched_at")==time && catalog.getInt("server_count")==count)
        val nodes=catalog.getJSONArray("servers"); check(nodes.length()==count)
        val out=ArrayList<VpnServer>(count)
        for(i in 0 until nodes.length()) {
            val row=nodes.getJSONObject(i)
            try {
                val ip=row.getString("ip"); val code=row.optString("country_code","")
                val name=row.optString("country_name","")
                if(!SrDirectoryPolicy.ipv4(ip) || !Regex("[A-Z]{2}").matches(code) || name.isBlank() || name=="null") continue
                if(!SrDirectoryPolicy.isFresh(row.getString("last_seen_at"),now,7*DAY)) continue
                val descriptor=row.getJSONObject("config")
                val ref=SrPoolRef.decode(SrPoolRef(commit,row.getString("openvpn_config_sha256"),row.getInt("openvpn_config_bytes"),descriptor.getString("sha256"),descriptor.getInt("bytes")).encode())
                check(descriptor.getString("path")==ref.path)
                fun metric(k:String)=row.optLong(k,0L).coerceAtLeast(0L)
                val ping=metric("ping_ms").takeIf{it>0}?.coerceAtMost(9998L)?.toInt() ?: 9999
                out.add(VpnServer(row.getString("hostname"),ip,metric("score"),ping,metric("speed_bps"),name,code,metric("num_vpn_sessions"),0,0,0,"Unknown","VPN Gate rolling pool","Previously observed; not a live connection test",ref.encode()))
            } catch(_:Exception) { /* Ignore malformed individual records; no dummy config. */ }
        }
        return out
    }
    suspend fun resolve(value:String):String {
        if(!SrPoolRef.isReference(value)) return value
        synchronized(cache) { cache[value] }?.let { return it }
        val ref=SrPoolRef.decode(value)
        val json=JSONObject(verified(ref.commit,ref.path,ref.fileSize,ref.fileHash).toString(Charsets.UTF_8))
        check(json.getInt("schema_version")==1 && json.getString("kind")=="vpngate-pool-config")
        check(json.getString("openvpn_config_sha256")==ref.hash && json.getInt("openvpn_config_bytes")==ref.size)
        val encoded=json.getString("openvpn_config_base64")
        val decoded=Base64.decode(encoded,Base64.DEFAULT)
        check(decoded.size==ref.size && SrDirectoryPolicy.sha256(decoded)==ref.hash && validProfile(encoded)) { "Invalid OpenVPN profile" }
        synchronized(cache) { cache[value]=encoded }
        return encoded
    }
}
