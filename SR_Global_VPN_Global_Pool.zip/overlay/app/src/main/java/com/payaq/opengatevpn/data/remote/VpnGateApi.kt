package com.payaq.opengatevpn.data.remote

import android.util.Base64
import android.util.Log
import com.payaq.opengatevpn.data.model.VpnServer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/** SR directory extension; compatible with upstream VpnRepository and ViewModel. */
sealed interface VpnGateResult {
    data class Success(val servers: List<VpnServer>, val duplicatesRemoved: Int = 0) : VpnGateResult
    data object EmptyFeed : VpnGateResult
    data class NetworkError(val cause: Throwable?) : VpnGateResult
}

class VpnGateApi {
    private val mirrorRoot = "https://raw.githubusercontent.com/GeorgeXie2333/vpngate-list-mirror"
    private suspend fun download(url: String, maxBytes: Int): ByteArray = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpsURLConnection
        c.connectTimeout = 7000; c.readTimeout = 8000; c.instanceFollowRedirects = false; c.useCaches = false
        try {
            check(c.responseCode == 200) { "Directory HTTP ${c.responseCode}" }
            val out = ByteArrayOutputStream()
            val started = System.nanoTime()
            c.inputStream.use { input ->
                val buf = ByteArray(16384)
                while (true) {
                    check((System.nanoTime()-started)/1_000_000L < 15000L) { "Directory read timeout" }
                    val n = input.read(buf); if (n < 0) break
                    check(out.size() + n <= maxBytes) { "Directory too large" }; out.write(buf,0,n)
                }
            }
            out.toByteArray()
        } finally { c.disconnect() }
    }
    suspend fun fetchVpnGate(): String = download("https://www.vpngate.net/api/iphone/", SrDirectoryPolicy.MAX_BYTES).toString(Charsets.UTF_8)
    private suspend fun fetchMirror(): String {
        val index = JSONObject(download("$mirrorRoot/main/latest.json",65536).toString(Charsets.UTF_8))
        check(index.getInt("schema_version") == 1)
        check(index.getString("source_url") == "https://www.vpngate.net/api/iphone/")
        check(SrDirectoryPolicy.isFresh(index.getString("fetched_at"),System.currentTimeMillis())) { "Mirror snapshot expired" }
        val commit = index.getString("data_commit"); check(Regex("[a-f0-9]{40}").matches(commit))
        val meta = index.getJSONObject("files").getJSONObject("data/vpngate.csv")
        val size = meta.getInt("bytes"); check(size in 1..SrDirectoryPolicy.MAX_BYTES)
        val hash = meta.getString("sha256"); check(Regex("[a-f0-9]{64}").matches(hash))
        val bytes = download("$mirrorRoot/$commit/data/vpngate.csv",size)
        check(bytes.size == size && SrDirectoryPolicy.sha256(bytes) == hash) { "Mirror integrity mismatch" }
        return bytes.toString(Charsets.UTF_8)
    }
    private fun parse(text: String): List<VpnServer> = SrDirectoryPolicy.parse(text, ::validProfile)
    private suspend fun fetchPool(): List<VpnServer> = SrRollingPool.fetch()
    private data class Feed(val rows: List<VpnServer>?, val failure: Throwable? = null)
    private suspend fun attempt(name: String, get: suspend () -> List<VpnServer>): Feed = try {
        Feed(get())
    } catch (e: CancellationException) { throw e } catch (e: Exception) {
        Log.w("SR_Directory", "$name unavailable", e); Feed(null,e)
    }
    suspend fun parseVpnGate(): VpnGateResult = coroutineScope {
        val live = async { attempt("Official") { parse(fetchVpnGate()) } }
        val backup = async { attempt("Recent mirror") { parse(fetchMirror()) } }
        val pool = async { attempt("Rolling pool", ::fetchPool) }
        val a = live.await(); val b = backup.await(); val c = pool.await()
        val merged = SrDirectoryPolicy.merge(SrDirectoryPolicy.merge(a.rows.orEmpty(),b.rows.orEmpty()),c.rows.orEmpty())
        if (merged.isNotEmpty()) {
            Log.i("SR_Directory", "Official=${a.rows?.size ?: 0}, mirror=${b.rows?.size ?: 0}, pool=${c.rows?.size ?: 0}, countries=${merged.map { it.countryShort }.distinct().size}")
            VpnGateResult.Success(merged,a.rows.orEmpty().size+b.rows.orEmpty().size+c.rows.orEmpty().size-merged.size)
        } else if (a.rows != null || b.rows != null || c.rows != null) VpnGateResult.EmptyFeed
        else VpnGateResult.NetworkError(a.failure ?: b.failure ?: c.failure)
    }
}

internal fun validProfile(encoded: String): Boolean = try {
    val profile = Base64.decode(encoded, Base64.DEFAULT).toString(Charsets.UTF_8)
    val lines = profile.lineSequence().map { it.trim() }.toList()
    lines.any { it.startsWith("remote ") } && lines.any { it == "client" || it == "tls-client" } &&
        profile.contains("<ca>") && profile.contains("</ca>")
} catch (_: IllegalArgumentException) { false }
