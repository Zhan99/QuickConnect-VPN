package com.payaq.opengatevpn.data.remote

import java.util.Base64
import java.text.SimpleDateFormat
import java.util.TimeZone

fun main() {
    val header = "*vpn_servers\n#HostName,IP,Score,Ping,Speed,CountryLong,CountryShort,NumVpnSessions,Uptime,TotalUsers,TotalTraffic,LogType,Operator,Message,OpenVPN_ConfigData_Base64\n"
    val conf = Base64.getEncoder().encodeToString(("client\nremote example.invalid 1194\n<ca>\n" + "a".repeat(140) + "\n</ca>\n").toByteArray())
    fun row(ip:String,country:String,code:String,ping:String="50",speed:String="1000",score:Int=1,config:String=conf) = "test,$ip,$score,$ping,$speed,$country,$code,1,100,1,100,2weeks,operator,\"message, with comma\",$config\n"
    fun parse(rows:String) = SrDirectoryPolicy.parse(header+rows+"*\n") { it == conf }
    val live = parse(row("192.0.2.1","Japan","JP",score=10)+row("192.0.2.1","Japan","JP",score=20)+row("192.0.2.2","Romania","RO","850"))
    val mirror = parse(row("192.0.2.1","Japan","JP",score=999)+row("192.0.2.3","Lithuania","LT","-","-")+row("192.0.2.4","Croatia","HR","1500")+row("bad","Norway","NO")+row("192.0.2.5","Fake","FA",config="garbage"))
    val merged = SrDirectoryPolicy.merge(live,mirror)
    check(merged.size==4)
    check(merged.map{it.countryShort}.toSet()==setOf("JP","RO","LT","HR"))
    check(merged.first{it.countryShort=="JP"}.score==20L)
    check(merged.first{it.countryShort=="RO"}.ping==850)
    check(merged.first{it.countryShort=="LT"}.ping==9999)
    check(merged.first{it.countryShort=="LT"}.speed==0L)
    check(merged.first{it.countryShort=="HR"}.message=="message, with comma")
    check(SrDirectoryPolicy.merge(live,emptyList()).size==2)
    check(SrDirectoryPolicy.merge(emptyList(),mirror).size==3)
    check(runCatching { SrDirectoryPolicy.parse(header+row("192.0.2.1","Japan","JP")){true} }.isFailure)
    val t=SimpleDateFormat("yyyy-MM-dd HH:mm:ss").apply {timeZone=TimeZone.getTimeZone("UTC")}.parse("2026-11-25 01:00:00")!!.time
    check(SrDirectoryPolicy.isFresh("2026-11-24T20:29:28.352Z",t))
    check(!SrDirectoryPolicy.isFresh("2026-11-24T18:00:00Z",t))
    check(!SrDirectoryPolicy.isFresh("2026-11-25T01:06:00Z",t))
    check(!SrDirectoryPolicy.isFresh("2026-02-30T01:00:00Z",t))
    check(SrDirectoryPolicy.sha256("abc".toByteArray())=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    val ref=SrPoolRef("a".repeat(40),"b".repeat(64),1024,"c".repeat(64),2048)
    check(SrPoolRef.decode(ref.encode())==ref)
    check(ref.path=="pool/configs/"+"b".repeat(64)+".json")
    check(!SrPoolRef.isReference(conf))
    check(runCatching { SrPoolRef.decode(ref.copy(commit="../bad").encode()) }.isFailure)
    check(runCatching { SrPoolRef.decode(ref.copy(size=131073).encode()) }.isFailure)
    check(SrDirectoryPolicy.isFresh("2026-11-24T18:00:00Z",t,86400000L))
    check(!SrDirectoryPolicy.isFresh("2026-11-17T18:00:00Z",t,7*86400000L))
    println("Pool reference tests passed: encode/decode, path, invalid commit/size, expiry")
    println("Directory policy tests passed: merge, four countries, duplicates, high/unknown latency, invalid rows, CSV quotes, truncated feed, mirror time/hash")
}
