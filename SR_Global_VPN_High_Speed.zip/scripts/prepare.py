import pathlib, re, shutil, sys, xml.etree.ElementTree as ET
root=pathlib.Path(sys.argv[1]); base=pathlib.Path(__file__).resolve().parents[1]
app=root/'app'; src=app/'src/main'; pkg=src/'java/com/payaq/opengatevpn'
def edit(p,a,b):
    t=p.read_text(); assert a in t, f'Upstream changed: {p}: {a}'; p.write_text(t.replace(a,b,1))
edit(app/'build.gradle.kts','applicationId = "com.payaq.opengatevpn"','applicationId = "com.srcreationfarm.globalvpn"')
# API 37 uses the major.minor SDK package naming.
gradle=app/'build.gradle.kts'
t=gradle.read_text()
t=t.replace('version = release(37)\n', 'version = release(37) { minorApiLevel = 0 }\n')
gradle.write_text(t)
m=src/'AndroidManifest.xml'
edit(m,'android:name=".MainActivity"','android:name="com.payaq.opengatevpn.MainActivity"')
edit(m,'</application>','<activity android:name="com.payaq.opengatevpn.SrToolsActivity" android:exported="false" />\n<activity android:name="com.payaq.opengatevpn.SrAppSettingsActivity" android:exported="false" />\n</application>')
# Scoped package visibility: list installed launcher apps without QUERY_ALL_PACKAGES.
edit(m,'<application', '<queries><intent><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent></queries>\n    <application')
# Apply routing preferences to the actual OpenVPN profile on every launch/retry/resume.
manager = pkg/'data/vpn/VpnManager.kt'
edit(manager, 'val profile = parser.convertProfile()', 'val profile = parser.convertProfile()\n            com.payaq.opengatevpn.SrRouting.apply(context, profile)')
# Use the existing top bar; keep splash, tab navigation and server list unchanged.
main = pkg/'ui/main/MainScreen.kt'
edit(main, 'onSettingsClick = { /* Future settings */ }', 'onSettingsClick = { /* menu handled in TopBar */ },\n                srState = state')
edit(main, 'onSettingsClick: () -> Unit\n', 'onSettingsClick: () -> Unit,\n    srState: ConnectionState\n')
# Anchor after the actual refresh icon, within its Row.
edit(main, '.rotate(if (isRefreshing) rotation else 0f)\n                )\n            }', '.rotate(if (isRefreshing) rotation else 0f)\n                )\n            }\n            com.payaq.opengatevpn.SrOverflow(srState, onRefreshClick)')
connection_tab = pkg/'ui/main/ConnectionTab.kt'
edit(connection_tab, 'import androidx.compose.foundation.Canvas', 'import androidx.compose.foundation.Canvas\nimport androidx.compose.foundation.verticalScroll\nimport androidx.compose.foundation.rememberScrollState')
edit(connection_tab, '.padding(horizontal = 20.dp),\n        horizontalAlignment', '.verticalScroll(rememberScrollState())\n            .padding(horizontal = 20.dp),\n        horizontalAlignment')
edit(connection_tab, 'Spacer(modifier = Modifier.weight(0.1f))', 'com.payaq.opengatevpn.SrExitCard(state, server?.ip, server?.countryLong)\n        Spacer(modifier = Modifier.height(10.dp))')
edit(connection_tab, 'Spacer(modifier = Modifier.weight(0.1f))', 'Spacer(modifier = Modifier.height(12.dp))')
# Shorten header label to keep menu accessible on narrow phones.
edit(main, 'text = "OpenGate",', 'text = "SR Global VPN",')
edit(main, 'MaterialTheme.typography.headlineMedium.copy(', 'MaterialTheme.typography.titleLarge.copy(')
# Avoid ConcurrentModificationException when a selected app is uninstalled mid-connect.
service = root/'vpnLib/src/main/java/de/blinkt/openvpn/core/OpenVPNService.java'
edit(service, 'for (String pkg : mProfile.mAllowedAppsVpn) {', 'for (String pkg : new java.util.HashSet<>(mProfile.mAllowedAppsVpn)) {')
for p in pkg.rglob('*.kt'):
    t=p.read_text(); u=t.replace('"OpenGate VPN"','"SR Global VPN"').replace('"OpenGate"','"SR Global VPN"');
    if u!=t: p.write_text(u)
for p in (src/'res').glob('values*/strings.xml'):
    t=p.read_text(); u=re.sub(r'(<string\s+name="app_name"[^>]*>).*?(</string>)',r'\1SR Global VPN\2',t,flags=re.S)
    if t!=u: p.write_text(u)
# Country list derives from displayServers upstream; expose total and distinguish listing from connectivity.
servers_ui = pkg/'ui/main/ServersTab.kt'
edit(servers_ui, '"${viewModel.displayServers.size} Nodes Available"', '"${viewModel.displayServers.size} listed nodes · ${viewModel.availableCountries.size} countries/regions"')
edit(servers_ui, '// Search Bar', '''Text(text = "VPN Gate + rolling pool · availability varies", style = TechnicalData, color = TextMuted)
        // Search Bar''')
model_ui = pkg/'data/model/VpnServerDisplay.kt'
edit(model_ui, 'val pingText: String = "${ping}ms"', 'val pingText: String = if (ping == 9999) "Unknown" else "${ping}ms"')
# A stale selected country must not hide all nodes after a refresh.
vm = pkg/'ui/main/VpnViewModel.kt'
edit(vm, 'val matchesCountry = selectedCountryFilter?.let { it == server.countryLong } ?: true', 'val matchesCountry = selectedCountryFilter?.takeIf { it in availableCountries }?.let { it == server.countryLong } ?: true')
# Resolve rolling-pool config references only at the actual connection boundary.
edit(pkg/'MainActivity.kt', "if (!viewModel.vpnManager.startVpn(config)) {\n                // Config died between request and grant — fail visibly, not via watchdog.\n                viewModel.onLaunchFailed()\n            }", "viewModel.srLaunchConfig(config)")
edit(pkg/'MainActivity.kt', "if (!viewModel.vpnManager.startVpn(configBase64)) {\n                viewModel.onLaunchFailed()\n            }", "viewModel.srLaunchConfig(configBase64)")
edit(vm, 'private var loadJob: Job? = null', 'private var loadJob: Job? = null\n    private var srProfileJob: Job? = null\n\n    /** Resolve a pinned pool profile off main; never start a cancelled or switched request. */\n    fun srLaunchConfig(config: String) {\n        srProfileJob?.cancel()\n        if (!com.payaq.opengatevpn.data.remote.SrPoolRef.isReference(config)) {\n            if (!vpnManager.startVpn(config)) onLaunchFailed()\n            return\n        }\n        connectionWatchdogJob?.cancel()\n        vpnStatus = "Loading selected server profile..."\n        srProfileJob = viewModelScope.launch {\n            val resolved = try {\n                com.payaq.opengatevpn.data.remote.SrRollingPool.resolve(config)\n            } catch (e: kotlinx.coroutines.CancellationException) { throw e }\n              catch (e: Exception) {\n                failConnection("Server profile unavailable", "Could not verify or download the selected server. Refresh or choose another server.", "Pool profile fetch failed")\n                return@launch\n            }\n            if (connectionState != ConnectionState.CONNECTING && connectionState != ConnectionState.RECONNECTING) return@launch\n            beginAttempt()\n            startConnectionWatchdog()\n            if (!vpnManager.startVpn(resolved)) onLaunchFailed()\n        }\n    }')
# The retry path also resolves references; pause/resume uses the manager's actual active config.
edit(vm, 'if (!vpnManager.startVpn(config)) {\n                    failConnection(headline, detail, "Retry attempt $attempt failed to launch.")\n                }', 'srLaunchConfig(config)')
# Do not allow pending profile downloads to launch after stop, failure or switch.
for anchor in ['private fun failConnection(headline: String, detail: String, logLine: String) {',  'fun onStopClicked() {']:
    edit(vm, anchor, anchor+'\n        srProfileJob?.cancel()')
edit(vm, 'val previousIp = selectedServer?.ip ?: "?"', 'srProfileJob?.cancel()\n        val previousIp = selectedServer?.ip ?: "?"')
edit(vm, 'if (connectionState == ConnectionState.PAUSED) {\n            // A stored pause session', 'srProfileJob?.cancel()\n        if (connectionState == ConnectionState.PAUSED) {\n            // A stored pause session')
edit(vm, 'if (!vpnManager.resumeVpn(bestServerConfig)) {', 'if (!vpnManager.resumeVpn(bestServerConfig?.takeUnless { com.payaq.opengatevpn.data.remote.SrPoolRef.isReference(it) })) {')
# Prefer current-source configs for automatic selection; all pool countries stay selectable.
edit(vm, 'val best = fetched.maxByOrNull { it.score } ?: fetched.first()', 'val best = fetched.filterNot { com.payaq.opengatevpn.data.remote.SrPoolRef.isReference(it.openVpnConfigDataBase64) }.maxByOrNull { it.score } ?: fetched.maxByOrNull { it.score } ?: fetched.first()')
# High-speed country mode. All changes are anchored to reviewed upstream source.
edit(vm, 'private var srProfileJob: Job? = null', '''private var srProfileJob: Job? = null
    private val srSpeedPrefs = application.getSharedPreferences("sr_speed", 0)
    var srHighSpeed by mutableStateOf(srSpeedPrefs.getBoolean("enabled", true))
        private set
    private val srTried = mutableSetOf<String>()
    private var srCountryLock: String? = null
    fun srToggleSpeed() {
        srHighSpeed = !srHighSpeed
        srSpeedPrefs.edit().putBoolean("enabled", srHighSpeed).apply()
    }
    private fun srBest(country: String? = null, excluded: Set<String> = emptySet()): VpnServer? =
        com.payaq.opengatevpn.data.remote.SrSpeedPolicy.best(fullServers, country, excluded)
    private fun srPick(requested: VpnServer): VpnServer = if (srHighSpeed && !residentialOnly)
        srBest(requested.countryShort) ?: requested else requested
    private fun srMarkAttempt() {
        selectedServer?.let { srTried.add(it.ip); srCountryLock = it.countryShort }
    }
    private fun srNext(): VpnServer? {
        if (!srHighSpeed || residentialOnly || manualSingleShotRetry) return null
        val country = srCountryLock ?: return null
        selectedServer?.let { srTried.add(it.ip) }
        return srBest(country, srTried)
    }''')
# Both server pickers share this switch path; keep exact-node choice when speed mode is off.
edit(vm, 'fun onServerSwitchRequested(newServer: VpnServer, onStartConnection: (String) -> Unit) {', '''fun onServerSwitchRequested(requestedServer: VpnServer, onStartConnection: (String) -> Unit) {
        val newServer = srPick(requestedServer)''')
edit(vm, 'val previousIp = selectedServer?.ip ?: "?"', 'srTried.clear()\n        srCountryLock = newServer.countryShort\n        val previousIp = selectedServer?.ip ?: "?"')
# Reset history only on explicit user connect, not permission continuation.
edit(vm, 'retryJob?.cancel()\n        switchLaunchJob?.cancel()\n        activeIntent = ConnectionIntent.CONNECT', '''if (connectionState != ConnectionState.CONNECTING) {
            srTried.clear()
            srCountryLock = selectedServer?.countryShort
        }
        retryJob?.cancel()
        switchLaunchJob?.cancel()
        activeIntent = ConnectionIntent.CONNECT''')
edit(vm, 'val config = bestServerConfig\n        if (config == null || connectAttempts >= MAX_CONNECT_ATTEMPTS)', '''var config = bestServerConfig
        if (config == null || connectAttempts >= MAX_CONNECT_ATTEMPTS)''')
edit(vm, 'connectAttempts++\n        stopTelemetry()', '''srProfileJob?.cancel()
        connectionWatchdogJob?.cancel()
        val alternate = srNext()
        if (alternate != null) {
            selectedServer = alternate
            bestServerConfig = alternate.openVpnConfigDataBase64
            config = alternate.openVpnConfigDataBase64
            isAutoSelectedBest = false
            addLog("SPEED", "Same-country fallback: ${alternate.countryLong} · ${alternate.ip}")
        }
        val retryConfig = config ?: return
        connectAttempts++
        stopTelemetry()''')
edit(vm, 'srLaunchConfig(config)\n            }\n        }\n    }\n    private fun startConnectionWatchdog()', 'srLaunchConfig(retryConfig)\n            }\n        }\n    }\n    private fun startConnectionWatchdog()')
# Make retries actually reset the watchdog on both inline and resolved profiles.
edit(vm, 'fun srLaunchConfig(config: String) {\n        srProfileJob?.cancel()', '''fun srLaunchConfig(config: String) {
        srProfileJob?.cancel()
        if (connectionState != ConnectionState.CONNECTING && connectionState != ConnectionState.RECONNECTING) return
        srMarkAttempt()
        beginAttempt()
        startConnectionWatchdog()''')
# Profile download and launch failures also use bounded fallback; no loop on a manual single-shot retry.
edit(vm, 'failConnection("Server profile unavailable", "Could not verify or download the selected server. Refresh or choose another server.", "Pool profile fetch failed")', 'scheduleConnectRetry("Server profile unavailable", "Could not verify or download the selected server. Refresh or choose another server.", "Pool profile fetch failed")')
edit(vm, 'fun onLaunchFailed() {\n        failConnection(', 'fun onLaunchFailed() {\n        scheduleConnectRetry(')
# After success a new recovery sequence may try alternates, not reuse a previously failed node first.
edit(vm, 'connectAttempts = 0\n                activeIntent = ConnectionIntent.NONE', 'connectAttempts = 0\n                srTried.clear()\n                srMarkAttempt()\n                activeIntent = ConnectionIntent.NONE')
# Default selection uses speed ranking, and refresh never silently changes a user-selected country.
edit(vm, 'val best = fetched.filterNot { com.payaq.opengatevpn.data.remote.SrPoolRef.isReference(it.openVpnConfigDataBase64) }.maxByOrNull { it.score } ?: fetched.maxByOrNull { it.score } ?: fetched.first()', '''val previousCountry = selectedServer?.countryShort
                val best = if (previousCountry != null) {
                    srBest(previousCountry) ?: selectedServer!!
                } else if (srHighSpeed) srBest() ?: fetched.first()
                else fetched.maxByOrNull { it.score } ?: fetched.first()''')
# Keep selected country's identity during directory refresh, including if the node disappears.
edit(vm, 'selectedServer = best\n                bestServerConfig = best.openVpnConfigDataBase64', 'selectedServer = best\n                srCountryLock = best.countryShort\n                bestServerConfig = best.openVpnConfigDataBase64')
# Add a visible switch in both server pickers. No new permissions or VPN traffic generator.
edit(servers_ui, '// Sort Filter Chips', 'com.payaq.opengatevpn.SrSpeedMode(viewModel)\n        // Sort Filter Chips')
edit(main, '// Quick search', 'com.payaq.opengatevpn.SrSpeedMode(viewModel)\n            // Quick search')
edit(connection_tab, 'com.payaq.opengatevpn.SrExitCard(state, server?.ip, server?.countryLong)', 'com.payaq.opengatevpn.SrExitCard(state, server?.ip, server?.countryLong)\n        com.payaq.opengatevpn.SrSpeedCard(state, server?.ip, viewModel)')

# Re-rank when the user connects after enabling speed mode; banner retry remains exact.
edit(vm, 'private fun srMarkAttempt() {', '''fun srConfigForConnect(): String? {
        val previous = selectedServer ?: return bestServerConfig
        val candidate = srPick(previous)
        if (candidate.ip != previous.ip) selectServer(candidate)
        return bestServerConfig
    }
    private fun srMarkAttempt() {''')
edit(connection_tab, 'val config = viewModel.bestServerConfig', 'val config = viewModel.srConfigForConnect()')
# Allow a deliberate same-country alternate when the tunnel is up but disappointing.
edit(vm, 'fun onServerSwitchRequested(requestedServer: VpnServer, onStartConnection: (String) -> Unit) {\n        val newServer = srPick(requestedServer)', '''fun srTryAlternative(onStartConnection: (String) -> Unit) {
        val current = selectedServer ?: return
        if (connectionState != ConnectionState.CONNECTED || residentialOnly) return
        val next = srBest(current.countryShort, setOf(current.ip)) ?: return
        onServerSwitchRequested(next, onStartConnection, exact = true)
    }
    fun srHasAlternative(): Boolean {
        val current = selectedServer ?: return false
        return !residentialOnly && displayServers.any { it.countryShort == current.countryShort && it.ip != current.ip }
    }
    fun onServerSwitchRequested(requestedServer: VpnServer, onStartConnection: (String) -> Unit, exact: Boolean = false) {
        val newServer = if (exact) requestedServer else srPick(requestedServer)''')
edit(connection_tab, 'SrSpeedCard(state, server?.ip, viewModel)', 'SrSpeedCard(state, server?.ip, viewModel, onConnectClicked)')
# Re-evaluate state at fetch completion, not at fetch launch, to preserve active routes.
edit(vm, 'applyFetchedServers(result, fetchDurationMs, isTunnelActive)', 'applyFetchedServers(result, fetchDurationMs, connectionState in setOf(ConnectionState.CONNECTED, ConnectionState.CONNECTING, ConnectionState.RECONNECTING, ConnectionState.PAUSED))')
edit(vm, 'if (currentInFetched != null) {\n                selectedServer = currentInFetched\n            }', 'if (currentInFetched != null && currentInFetched.countryShort == selectedServer?.countryShort) {\n                selectedServer = currentInFetched\n            }')
# Stop the old gateway on a real fallback before launching the replacement. The retry intent suppresses stale teardown.
edit(vm, 'activeIntent = ConnectionIntent.AUTO_RETRY // suppress stale teardown events while retrying', 'activeIntent = ConnectionIntent.AUTO_RETRY // suppress stale teardown events while retrying\n        if (alternate != null) vpnManager.stopVpn()')

shutil.copytree(base/'overlay',root,dirs_exist_ok=True); ET.parse(m)
shutil.copy2(base/'LICENSE-SR', root/'LICENSE-SR')
print('SR overlay applied')
