package com.payaq.opengatevpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.payaq.opengatevpn.ui.main.ConnectionState
import com.payaq.opengatevpn.ui.main.VpnViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL
import java.util.Locale
import javax.net.ssl.HttpsURLConnection

/** Bounded, user-requested download benchmark, pinned to the current Android network. */
internal object SrSpeedSample {
    fun measure(context: Context, requireVpn: Boolean): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: error("No network")
        val vpn = cm.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        check(!requireVpn || vpn) { "No active VPN" }
        val limit = 2_000_000
        val conn = network.openConnection(URL("https://speed.cloudflare.com/__down?bytes=$limit")) as HttpsURLConnection
        conn.connectTimeout = 6000
        conn.readTimeout = 5000
        conn.instanceFollowRedirects = false
        conn.useCaches = false
        conn.setRequestProperty("Accept-Encoding", "identity")
        var total = 0
        val started = System.nanoTime()
        try {
            check(conn.responseCode == 200)
            conn.inputStream.use { input ->
                val buf = ByteArray(16384)
                while (total < limit) {
                    check((System.nanoTime() - started) < 18_000_000_000L) { "Test timed out" }
                    val n = input.read(buf, 0, minOf(buf.size, limit - total))
                    if (n < 0) break
                    total += n
                }
            }
        } finally { conn.disconnect() }
        val seconds = (System.nanoTime() - started) / 1e9
        check(total == limit && seconds > 0)
        check(cm.activeNetwork == network &&
            (cm.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) == vpn) { "Network changed" }
        return String.format(Locale.US, "%.2f Mbps · %s · 2 MB HTTPS sample", total * 8.0 / seconds / 1e6, if (vpn) "VPN" else "direct")
    }
}

@Composable
fun SrSpeedMode(viewModel: VpnViewModel) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Country high-speed mode", style = MaterialTheme.typography.titleSmall)
            Text(if (viewModel.srHighSpeed) "Choose a country via any node; estimated best relay first. Residential filter keeps exact selection." else "Choose an exact relay; no speed-based fallback.", style = MaterialTheme.typography.labelSmall)
        }
        Switch(checked = viewModel.srHighSpeed, onCheckedChange = { viewModel.srToggleSpeed() })
    }
}

@Composable
fun SrSpeedCard(state: ConnectionState, relayIp: String?, viewModel: VpnViewModel, onConnectClicked: (String) -> Unit) {
    val context = LocalContext.current.applicationContext
    var result by remember(state, relayIp) { mutableStateOf<String?>(null) }
    var running by remember(state, relayIp) { mutableStateOf(false) }
    // Cancellation on relay/state change; a result from the previous tunnel is not shown.
    var request by remember(state, relayIp) { mutableStateOf(0) }
    LaunchedEffect(state, relayIp, request) {
        if (state != ConnectionState.CONNECTED || request == 0) return@LaunchedEffect
        running = true
        result = null
        try {
            result = withContext(Dispatchers.IO) { SrSpeedSample.measure(context, true) }
        } catch (e: CancellationException) { throw e }
          catch (_: Exception) { result = "VPN speed test failed or network changed. Try another relay." }
        finally { running = false }
    }
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            SrSpeedMode(viewModel)
            if (state == ConnectionState.CONNECTED) {
                Text("Live traffic: ↓ ${viewModel.downloadSpeed}  ↑ ${viewModel.uploadSpeed}", style = MaterialTheme.typography.bodySmall)
                Text(result ?: "Actual capacity varies; idle traffic is not a slow connection.", style = MaterialTheme.typography.labelSmall)
                TextButton(enabled = !running, onClick = { request++; running = true }) { Text(if (running) "Measuring…" else "Test VPN download (2 MB)") }
                TextButton(enabled = !running && viewModel.srHasAlternative(), onClick = { viewModel.srTryAlternative(onConnectClicked) }) { Text("Try another fast relay in this country") }
                Text("Switching relays changes IP and can interrupt apps.", style = MaterialTheme.typography.labelSmall)
            } else Text("High-speed mode ranks directory estimates. No background speed-test downloads.", style = MaterialTheme.typography.labelSmall)
        }
    }
}
