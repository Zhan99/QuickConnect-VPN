package com.payaq.opengatevpn.data.remote

import com.payaq.opengatevpn.data.model.VpnServer
import kotlin.math.ln

/** Estimated ranking only: feed metrics are not device-to-relay measurements. */
internal object SrSpeedPolicy {
    fun rank(s: VpnServer): Double {
        val mbps = s.speed.coerceAtLeast(0L).coerceAtMost(10_000_000_000L) / 1_000_000.0
        val latency = s.ping.takeIf { it in 15..9998 } ?: 500
        val throughput = ln(1.0 + mbps) * 30.0
        val delay = ln(1.0 + latency / 40.0) * 12.0
        val load = ln(1.0 + s.numVpnSessions.coerceIn(0L, 10000L).toDouble()) * 3.0
        val reliability = ln(1.0 + s.score.coerceIn(0L, 100000000L).toDouble()) * 0.8
        val freshness = if (SrPoolRef.isReference(s.openVpnConfigDataBase64)) -40.0 else 0.0
        return throughput - delay - load + reliability + freshness
    }
    fun best(rows: List<VpnServer>, country: String? = null, excluded: Set<String> = emptySet()): VpnServer? =
        rows.asSequence().filter { (country == null || it.countryShort.equals(country, true)) && it.ip !in excluded }
            .maxWithOrNull(compareBy<VpnServer> { rank(it) }.thenBy { it.speed }.thenByDescending { it.ip })
}
