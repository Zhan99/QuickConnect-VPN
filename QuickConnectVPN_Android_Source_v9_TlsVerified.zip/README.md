# QuickConnect VPN (v1.6.0 - Full TLS SSL Certificate Verification)

Developed by **Shahriar Rahman** | **SR Creation Farm**
- YouTube: https://www.youtube.com/@SRCreation-farm
- Facebook: https://fb.com/srcreation.farm
