package com.srcreationfarm.quickvpn

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.srcreationfarm.quickvpn.databinding.ItemServerBinding

class ServerAdapter(
    private val servers: List<ServerLocation>,
    private var selectedId: String,
    private val onServerSelected: (ServerLocation) -> Unit
) : RecyclerView.Adapter<ServerAdapter.ServerViewHolder>() {

    private var showPing = false

    fun setSelectedServer(id: String) {
        val oldIndex = servers.indexOfFirst { it.id == selectedId }
        val newIndex = servers.indexOfFirst { it.id == id }
        selectedId = id
        if (oldIndex != -1) notifyItemChanged(oldIndex)
        if (newIndex != -1) notifyItemChanged(newIndex)
    }

    fun setShowPing(show: Boolean) {
        showPing = show
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServerViewHolder {
        val binding = ItemServerBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ServerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ServerViewHolder, position: Int) {
        holder.bind(servers[position])
    }

    override fun getItemCount(): Int = servers.size

    inner class ServerViewHolder(
        private val binding: ItemServerBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(server: ServerLocation) {
            val isSelected = server.id == selectedId
            val context = binding.root.context

            binding.rowRoot.setBackgroundColor(
                ContextCompat.getColor(
                    context,
                    if (isSelected) R.color.row_selected else R.color.row_default
                )
            )

            val signalRes = when (server.signalLevel) {
                4 -> R.drawable.ic_signal_4
                3 -> R.drawable.ic_signal_3
                1 -> R.drawable.ic_signal_1
                else -> R.drawable.ic_signal_2
            }
            binding.ivSignal.setImageResource(signalRes)
            binding.ivFlag.setImageBitmap(FlagRenderer.getFlagBitmap(server.countryCode))
            binding.tvCountryName.text = server.countryName

            if (showPing && server.proxyHost.isNotEmpty()) {
                binding.tvPing.visibility = View.VISIBLE
                binding.tvPing.text = "${server.latencyMs} ms"
            } else {
                binding.tvPing.visibility = View.GONE
            }

            binding.rowRoot.setOnClickListener {
                onServerSelected(server)
            }
        }
    }
}
