package com.srcreationfarm.quickvpn

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.sin

object FlagRenderer {

    private val cache = mutableMapOf<String, Bitmap>()

    fun getFlagBitmap(countryCode: String): Bitmap {
        cache[countryCode]?.let { return it }

        val width = 140
        val height = 96
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val w = width.toFloat()
        val h = height.toFloat()

        when (countryCode) {
            "SG" -> {
                drawHorizontal2(canvas, w, h, "#EF3340", "#FFFFFF", paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.23f, h * 0.25f, h * 0.16f, paint)
                paint.color = Color.parseColor("#EF3340")
                canvas.drawCircle(w * 0.28f, h * 0.25f, h * 0.15f, paint)
                paint.color = Color.WHITE
                for (deg in listOf(0.0, 72.0, 144.0, 216.0, 288.0)) {
                    val rad = Math.toRadians(deg - 90.0)
                    canvas.drawCircle(
                        w * 0.33f + (h * 0.08f * cos(rad)).toFloat(),
                        h * 0.25f + (h * 0.08f * sin(rad)).toFloat(),
                        2.2f,
                        paint
                    )
                }
            }
            "IN" -> {
                drawHorizontal3(canvas, w, h, "#FF9933", "#FFFFFF", "#138808", paint)
                paint.color = Color.parseColor("#000080")
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2.5f
                canvas.drawCircle(w / 2f, h / 2f, h * 0.12f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(w / 2f, h / 2f, 2.5f, paint)
            }
            "KR" -> {
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w, h, paint)
                val cx = w / 2f
                val cy = h / 2f
                val r = h * 0.22f
                paint.color = Color.parseColor("#CD2E3A")
                canvas.drawArc(cx - r, cy - r, cx + r, cy + r, 180f, 180f, true, paint)
                paint.color = Color.parseColor("#0047A0")
                canvas.drawArc(cx - r, cy - r, cx + r, cy + r, 0f, 180f, true, paint)
                paint.color = Color.parseColor("#CD2E3A")
                canvas.drawCircle(cx - r / 2f, cy, r / 2f, paint)
                paint.color = Color.parseColor("#0047A0")
                canvas.drawCircle(cx + r / 2f, cy, r / 2f, paint)
                paint.color = Color.BLACK
                paint.strokeWidth = 3f
                canvas.drawLine(w * 0.20f, h * 0.20f, w * 0.30f, h * 0.30f, paint)
                canvas.drawLine(w * 0.70f, h * 0.30f, w * 0.80f, h * 0.20f, paint)
                canvas.drawLine(w * 0.20f, h * 0.80f, w * 0.30f, h * 0.70f, paint)
                canvas.drawLine(w * 0.70f, h * 0.70f, w * 0.80f, h * 0.80f, paint)
            }
            "AU" -> {
                paint.color = Color.parseColor("#00008B")
                canvas.drawRect(0f, 0f, w, h, paint)
                drawUnionJack(canvas, w / 2f, h / 2f, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.25f, h * 0.75f, 5.5f, paint)
                canvas.drawCircle(w * 0.75f, h * 0.22f, 3.5f, paint)
                canvas.drawCircle(w * 0.68f, h * 0.45f, 3.5f, paint)
                canvas.drawCircle(w * 0.83f, h * 0.42f, 3.5f, paint)
                canvas.drawCircle(w * 0.75f, h * 0.78f, 4.0f, paint)
            }
            "NZ" -> {
                paint.color = Color.parseColor("#00247D")
                canvas.drawRect(0f, 0f, w, h, paint)
                drawUnionJack(canvas, w / 2f, h / 2f, paint)
                paint.color = Color.parseColor("#CC142B")
                canvas.drawCircle(w * 0.75f, h * 0.22f, 3.8f, paint)
                canvas.drawCircle(w * 0.68f, h * 0.45f, 3.8f, paint)
                canvas.drawCircle(w * 0.83f, h * 0.42f, 3.8f, paint)
                canvas.drawCircle(w * 0.75f, h * 0.78f, 4.2f, paint)
            }
            "JP" -> {
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#BC002D")
                canvas.drawCircle(w / 2f, h / 2f, h * 0.28f, paint)
            }
            "US_EAST", "US_WEST", "US" -> {
                val stripeH = h / 13f
                for (i in 0 until 13) {
                    paint.color = if (i % 2 == 0) Color.parseColor("#B22234") else Color.WHITE
                    canvas.drawRect(0f, i * stripeH, w, (i + 1) * stripeH, paint)
                }
                paint.color = Color.parseColor("#3C3B6E")
                canvas.drawRect(0f, 0f, w * 0.42f, stripeH * 7f, paint)
                paint.color = Color.WHITE
                for (row in 0 until 4) {
                    for (col in 0 until 5) {
                        canvas.drawCircle(
                            w * 0.05f + col * (w * 0.08f),
                            stripeH * 1.1f + row * (stripeH * 1.6f),
                            1.8f,
                            paint
                        )
                    }
                }
            }
            "CA" -> {
                paint.color = Color.parseColor("#D80621")
                canvas.drawRect(0f, 0f, w * 0.26f, h, paint)
                canvas.drawRect(w * 0.74f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(w * 0.26f, 0f, w * 0.74f, h, paint)
                paint.color = Color.parseColor("#D80621")
                val leaf = Path().apply {
                    moveTo(w * 0.50f, h * 0.20f)
                    lineTo(w * 0.56f, h * 0.36f)
                    lineTo(w * 0.65f, h * 0.34f)
                    lineTo(w * 0.60f, h * 0.52f)
                    lineTo(w * 0.66f, h * 0.56f)
                    lineTo(w * 0.52f, h * 0.66f)
                    lineTo(w * 0.52f, h * 0.80f)
                    lineTo(w * 0.48f, h * 0.80f)
                    lineTo(w * 0.48f, h * 0.66f)
                    lineTo(w * 0.34f, h * 0.56f)
                    lineTo(w * 0.40f, h * 0.52f)
                    lineTo(w * 0.35f, h * 0.34f)
                    lineTo(w * 0.44f, h * 0.36f)
                    close()
                }
                canvas.drawPath(leaf, paint)
            }
            "GB" -> drawUnionJack(canvas, w, h, paint)
            "DE" -> drawHorizontal3(canvas, w, h, "#111111", "#DD0000", "#FFCE00", paint)
            "NL" -> drawHorizontal3(canvas, w, h, "#AE1C28", "#FFFFFF", "#21468B", paint)
            "RU" -> drawHorizontal3(canvas, w, h, "#FFFFFF", "#0039A6", "#D52B1E", paint)
            "AT" -> drawHorizontal3(canvas, w, h, "#ED2939", "#FFFFFF", "#ED2939", paint)
            "HU" -> drawHorizontal3(canvas, w, h, "#CE2939", "#FFFFFF", "#477050", paint)
            "BG" -> drawHorizontal3(canvas, w, h, "#FFFFFF", "#00966E", "#D62612", paint)
            "LT" -> drawHorizontal3(canvas, w, h, "#FDB913", "#006A44", "#C1272D", paint)
            "EE" -> drawHorizontal3(canvas, w, h, "#0072CE", "#111111", "#FFFFFF", paint)
            "LV" -> {
                paint.color = Color.parseColor("#9E3039")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(0f, h * 0.40f, w, h * 0.60f, paint)
            }
            "LU" -> drawHorizontal3(canvas, w, h, "#EA141D", "#FFFFFF", "#51ADDA", paint)
            "HR" -> drawHorizontal3(canvas, w, h, "#FF0000", "#FFFFFF", "#171796", paint)
            "RS" -> drawHorizontal3(canvas, w, h, "#C6363C", "#0C4076", "#FFFFFF", paint)
            "SK" -> drawHorizontal3(canvas, w, h, "#FFFFFF", "#0B4EA2", "#EE1C25", paint)
            "SI" -> drawHorizontal3(canvas, w, h, "#FFFFFF", "#003DA5", "#ED1C24", paint)
            "AM" -> drawHorizontal3(canvas, w, h, "#D90012", "#0033A0", "#F2A800", paint)
            "AZ" -> drawHorizontal3(canvas, w, h, "#00B5E2", "#EF3340", "#509E2F", paint)
            "EG" -> drawHorizontal3(canvas, w, h, "#CE1126", "#FFFFFF", "#111111", paint)
            "IQ" -> drawHorizontal3(canvas, w, h, "#CE1126", "#FFFFFF", "#111111", paint)
            "IR" -> drawHorizontal3(canvas, w, h, "#239F40", "#FFFFFF", "#DA0000", paint)
            "AR" -> {
                drawHorizontal3(canvas, w, h, "#74ACDF", "#FFFFFF", "#74ACDF", paint)
                paint.color = Color.parseColor("#F6B40E")
                canvas.drawCircle(w / 2f, h / 2f, h * 0.13f, paint)
            }
            "CO" -> {
                paint.color = Color.parseColor("#FCD116")
                canvas.drawRect(0f, 0f, w, h * 0.50f, paint)
                paint.color = Color.parseColor("#003893")
                canvas.drawRect(0f, h * 0.50f, w, h * 0.75f, paint)
                paint.color = Color.parseColor("#CE1126")
                canvas.drawRect(0f, h * 0.75f, w, h, paint)
            }
            "EC" -> {
                paint.color = Color.parseColor("#FFDD00")
                canvas.drawRect(0f, 0f, w, h * 0.50f, paint)
                paint.color = Color.parseColor("#034EA2")
                canvas.drawRect(0f, h * 0.50f, w, h * 0.75f, paint)
                paint.color = Color.parseColor("#ED1C24")
                canvas.drawRect(0f, h * 0.75f, w, h, paint)
            }
            "VE" -> drawHorizontal3(canvas, w, h, "#FCE300", "#003DA5", "#EF3340", paint)
            "BO" -> drawHorizontal3(canvas, w, h, "#D52B1E", "#F9E300", "#007934", paint)
            "PY" -> drawHorizontal3(canvas, w, h, "#D52B1E", "#FFFFFF", "#0038A8", paint)
            "GH" -> drawHorizontal3(canvas, w, h, "#CE1126", "#FCD116", "#006B3F", paint)
            "FR" -> drawVertical3(canvas, w, h, "#002395", "#FFFFFF", "#ED2939", paint)
            "IT" -> drawVertical3(canvas, w, h, "#009246", "#FFFFFF", "#CE2B37", paint)
            "BE" -> drawVertical3(canvas, w, h, "#111111", "#FDDA24", "#EF3340", paint)
            "IE" -> drawVertical3(canvas, w, h, "#169B62", "#FFFFFF", "#FF883E", paint)
            "RO" -> drawVertical3(canvas, w, h, "#002B7F", "#FCD116", "#CE1126", paint)
            "MD" -> drawVertical3(canvas, w, h, "#0046AE", "#FFD200", "#CC092F", paint)
            "MX" -> {
                drawVertical3(canvas, w, h, "#006847", "#FFFFFF", "#CE1126", paint)
                paint.color = Color.parseColor("#8B5A2B")
                canvas.drawCircle(w / 2f, h / 2f, h * 0.11f, paint)
            }
            "PE" -> drawVertical3(canvas, w, h, "#D91023", "#FFFFFF", "#D91023", paint)
            "NG" -> drawVertical3(canvas, w, h, "#008751", "#FFFFFF", "#008751", paint)
            "CI" -> drawVertical3(canvas, w, h, "#F77F00", "#FFFFFF", "#009E60", paint)
            "PL" -> drawHorizontal2(canvas, w, h, "#FFFFFF", "#DC143C", paint)
            "ID" -> drawHorizontal2(canvas, w, h, "#FF0000", "#FFFFFF", paint)
            "UA" -> drawHorizontal2(canvas, w, h, "#0057B7", "#FFD700", paint)
            "SE" -> drawNordicCross(canvas, w, h, "#006AA7", "#FECC02", null, paint)
            "FI" -> drawNordicCross(canvas, w, h, "#FFFFFF", "#003580", null, paint)
            "DK" -> drawNordicCross(canvas, w, h, "#C8102E", "#FFFFFF", null, paint)
            "NO" -> drawNordicCross(canvas, w, h, "#BA0C2F", "#FFFFFF", "#00205B", paint)
            "IS" -> drawNordicCross(canvas, w, h, "#02529C", "#FFFFFF", "#DC1E35", paint)
            "CH" -> {
                paint.color = Color.parseColor("#DA291C")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(w * 0.43f, h * 0.20f, w * 0.57f, h * 0.80f, paint)
                canvas.drawRect(w * 0.28f, h * 0.40f, w * 0.72f, h * 0.60f, paint)
            }
            "ES" -> {
                paint.color = Color.parseColor("#AA151B")
                canvas.drawRect(0f, 0f, w, h * 0.25f, paint)
                canvas.drawRect(0f, h * 0.75f, w, h, paint)
                paint.color = Color.parseColor("#F1BF00")
                canvas.drawRect(0f, h * 0.25f, w, h * 0.75f, paint)
                paint.color = Color.parseColor("#AA151B")
                canvas.drawRect(w * 0.26f, h * 0.38f, w * 0.36f, h * 0.62f, paint)
            }
            "PT" -> {
                paint.color = Color.parseColor("#006600")
                canvas.drawRect(0f, 0f, w * 0.40f, h, paint)
                paint.color = Color.parseColor("#FF0000")
                canvas.drawRect(w * 0.40f, 0f, w, h, paint)
                paint.color = Color.parseColor("#FFCC00")
                canvas.drawCircle(w * 0.40f, h / 2f, h * 0.18f, paint)
            }
            "GR" -> {
                val sh = h / 9f
                for (i in 0 until 9) {
                    paint.color = if (i % 2 == 0) Color.parseColor("#0D5EAF") else Color.WHITE
                    canvas.drawRect(0f, i * sh, w, (i + 1) * sh, paint)
                }
                paint.color = Color.parseColor("#0D5EAF")
                canvas.drawRect(0f, 0f, sh * 5f, sh * 5f, paint)
                paint.color = Color.WHITE
                canvas.drawRect(sh * 2f, 0f, sh * 3f, sh * 5f, paint)
                canvas.drawRect(0f, sh * 2f, sh * 5f, sh * 3f, paint)
            }
            "TR" -> {
                paint.color = Color.parseColor("#E30A17")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.38f, h / 2f, h * 0.24f, paint)
                paint.color = Color.parseColor("#E30A17")
                canvas.drawCircle(w * 0.44f, h / 2f, h * 0.19f, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.58f, h / 2f, h * 0.08f, paint)
            }
            "PK" -> {
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w * 0.26f, h, paint)
                paint.color = Color.parseColor("#01411C")
                canvas.drawRect(w * 0.26f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.62f, h / 2f, h * 0.24f, paint)
                paint.color = Color.parseColor("#01411C")
                canvas.drawCircle(w * 0.67f, h * 0.45f, h * 0.20f, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.72f, h * 0.38f, h * 0.07f, paint)
            }
            "BD" -> {
                paint.color = Color.parseColor("#006A4E")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#F42A41")
                canvas.drawCircle(w * 0.45f, h / 2f, h * 0.28f, paint)
            }
            "VN" -> {
                paint.color = Color.parseColor("#DA251D")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#FFFF00")
                canvas.drawCircle(w / 2f, h / 2f, h * 0.20f, paint)
            }
            "CN" -> {
                paint.color = Color.parseColor("#EE1C25")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#FFFF00")
                canvas.drawCircle(w * 0.22f, h * 0.30f, h * 0.14f, paint)
                canvas.drawCircle(w * 0.36f, h * 0.16f, 3.2f, paint)
                canvas.drawCircle(w * 0.42f, h * 0.26f, 3.2f, paint)
                canvas.drawCircle(w * 0.42f, h * 0.40f, 3.2f, paint)
                canvas.drawCircle(w * 0.36f, h * 0.50f, 3.2f, paint)
            }
            "HK" -> {
                paint.color = Color.parseColor("#DE2910")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w / 2f, h / 2f, h * 0.22f, paint)
            }
            "TW" -> {
                paint.color = Color.parseColor("#FE0000")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#000095")
                canvas.drawRect(0f, 0f, w * 0.50f, h * 0.50f, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.25f, h * 0.25f, h * 0.13f, paint)
            }
            "TH" -> {
                paint.color = Color.parseColor("#A51931")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(0f, h * 0.17f, w, h * 0.83f, paint)
                paint.color = Color.parseColor("#2D2A4A")
                canvas.drawRect(0f, h * 0.33f, w, h * 0.67f, paint)
            }
            "MY" -> {
                val sh = h / 14f
                for (i in 0 until 14) {
                    paint.color = if (i % 2 == 0) Color.parseColor("#CC0001") else Color.WHITE
                    canvas.drawRect(0f, i * sh, w, (i + 1) * sh, paint)
                }
                paint.color = Color.parseColor("#010066")
                canvas.drawRect(0f, 0f, w * 0.50f, sh * 8f, paint)
                paint.color = Color.parseColor("#FFCC00")
                canvas.drawCircle(w * 0.22f, sh * 4f, sh * 2.4f, paint)
            }
            "PH" -> {
                paint.color = Color.parseColor("#0038A8")
                canvas.drawRect(0f, 0f, w, h / 2f, paint)
                paint.color = Color.parseColor("#CE1126")
                canvas.drawRect(0f, h / 2f, w, h, paint)
                paint.color = Color.WHITE
                val tri = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w * 0.42f, h / 2f)
                    lineTo(0f, h)
                    close()
                }
                canvas.drawPath(tri, paint)
                paint.color = Color.parseColor("#FCD116")
                canvas.drawCircle(w * 0.16f, h / 2f, h * 0.12f, paint)
            }
            "BR" -> {
                paint.color = Color.parseColor("#009C3B")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#FFDF00")
                val diamond = Path().apply {
                    moveTo(w / 2f, h * 0.12f)
                    lineTo(w * 0.88f, h / 2f)
                    lineTo(w / 2f, h * 0.88f)
                    lineTo(w * 0.12f, h / 2f)
                    close()
                }
                canvas.drawPath(diamond, paint)
                paint.color = Color.parseColor("#002776")
                canvas.drawCircle(w / 2f, h / 2f, h * 0.21f, paint)
            }
            "CL" -> {
                drawHorizontal2(canvas, w, h, "#FFFFFF", "#D52B1E", paint)
                paint.color = Color.parseColor("#0039A6")
                canvas.drawRect(0f, 0f, w * 0.36f, h / 2f, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.18f, h * 0.25f, h * 0.10f, paint)
            }
            "CZ" -> {
                drawHorizontal2(canvas, w, h, "#FFFFFF", "#D7141A", paint)
                paint.color = Color.parseColor("#11457E")
                val tri = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w * 0.45f, h / 2f)
                    lineTo(0f, h)
                    close()
                }
                canvas.drawPath(tri, paint)
            }
            "AE" -> {
                drawHorizontal3(canvas, w, h, "#00732F", "#FFFFFF", "#111111", paint)
                paint.color = Color.parseColor("#FF0000")
                canvas.drawRect(0f, 0f, w * 0.26f, h, paint)
            }
            "SA" -> {
                paint.color = Color.parseColor("#006C35")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(w * 0.22f, h * 0.62f, w * 0.78f, h * 0.68f, paint)
                canvas.drawRect(w * 0.26f, h * 0.34f, w * 0.74f, h * 0.46f, paint)
            }
            "QA" -> {
                paint.color = Color.parseColor("#8D1B3D")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w * 0.32f, h, paint)
            }
            "IL" -> {
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#0038B8")
                canvas.drawRect(0f, h * 0.14f, w, h * 0.28f, paint)
                canvas.drawRect(0f, h * 0.72f, w, h * 0.86f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f
                canvas.drawCircle(w / 2f, h / 2f, h * 0.14f, paint)
                paint.style = Paint.Style.FILL
            }
            "ZA" -> {
                paint.color = Color.parseColor("#E03C31")
                canvas.drawRect(0f, 0f, w, h / 2f, paint)
                paint.color = Color.parseColor("#001489")
                canvas.drawRect(0f, h / 2f, w, h, paint)
                paint.color = Color.parseColor("#007749")
                canvas.drawRect(0f, h * 0.38f, w, h * 0.62f, paint)
                val tri = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w * 0.44f, h / 2f)
                    lineTo(0f, h)
                    close()
                }
                canvas.drawPath(tri, paint)
                paint.color = Color.BLACK
                val innerTri = Path().apply {
                    moveTo(0f, h * 0.16f)
                    lineTo(w * 0.26f, h / 2f)
                    lineTo(0f, h * 0.84f)
                    close()
                }
                canvas.drawPath(innerTri, paint)
            }
            "KZ" -> {
                paint.color = Color.parseColor("#00AFCA")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#FEC50C")
                canvas.drawCircle(w / 2f, h / 2f, h * 0.22f, paint)
            }
            "GE" -> {
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#FF0000")
                canvas.drawRect(w * 0.44f, 0f, w * 0.56f, h, paint)
                canvas.drawRect(0f, h * 0.40f, w, h * 0.60f, paint)
                canvas.drawCircle(w * 0.22f, h * 0.22f, 4f, paint)
                canvas.drawCircle(w * 0.78f, h * 0.22f, 4f, paint)
                canvas.drawCircle(w * 0.22f, h * 0.78f, 4f, paint)
                canvas.drawCircle(w * 0.78f, h * 0.78f, 4f, paint)
            }
            "AL" -> {
                paint.color = Color.parseColor("#E41E20")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.BLACK
                canvas.drawCircle(w / 2f, h / 2f, h * 0.20f, paint)
            }
            "CY" -> {
                paint.color = Color.WHITE
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.parseColor("#D57800")
                canvas.drawCircle(w / 2f, h * 0.46f, h * 0.20f, paint)
            }
            "NP" -> {
                paint.color = Color.parseColor("#DC143C")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(w * 0.35f, h * 0.34f, h * 0.11f, paint)
                canvas.drawCircle(w * 0.35f, h * 0.68f, h * 0.13f, paint)
            }
            else -> {
                paint.color = Color.parseColor("#3F51B5")
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.color = Color.WHITE
                paint.textSize = 36f
                paint.typeface = Typeface.DEFAULT_BOLD
                paint.textAlign = Paint.Align.CENTER
                val label = countryCode.take(3)
                canvas.drawText(label, w / 2f, h * 0.62f, paint)
            }
        }

        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#26000000")
        paint.strokeWidth = 2f
        canvas.drawRect(0f, 0f, w, h, paint)

        cache[countryCode] = bmp
        return bmp
    }

    private fun drawHorizontal2(
        canvas: Canvas,
        w: Float,
        h: Float,
        topHex: String,
        bottomHex: String,
        paint: Paint
    ) {
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor(topHex)
        canvas.drawRect(0f, 0f, w, h / 2f, paint)
        paint.color = Color.parseColor(bottomHex)
        canvas.drawRect(0f, h / 2f, w, h, paint)
    }

    private fun drawHorizontal3(
        canvas: Canvas,
        w: Float,
        h: Float,
        c1: String,
        c2: String,
        c3: String,
        paint: Paint
    ) {
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor(c1)
        canvas.drawRect(0f, 0f, w, h / 3f, paint)
        paint.color = Color.parseColor(c2)
        canvas.drawRect(0f, h / 3f, w, h * 2f / 3f, paint)
        paint.color = Color.parseColor(c3)
        canvas.drawRect(0f, h * 2f / 3f, w, h, paint)
    }

    private fun drawVertical3(
        canvas: Canvas,
        w: Float,
        h: Float,
        c1: String,
        c2: String,
        c3: String,
        paint: Paint
    ) {
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor(c1)
        canvas.drawRect(0f, 0f, w / 3f, h, paint)
        paint.color = Color.parseColor(c2)
        canvas.drawRect(w / 3f, 0f, w * 2f / 3f, h, paint)
        paint.color = Color.parseColor(c3)
        canvas.drawRect(w * 2f / 3f, 0f, w, h, paint)
    }

    private fun drawNordicCross(
        canvas: Canvas,
        w: Float,
        h: Float,
        bgHex: String,
        outerCrossHex: String,
        innerCrossHex: String?,
        paint: Paint
    ) {
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor(bgHex)
        canvas.drawRect(0f, 0f, w, h, paint)

        paint.color = Color.parseColor(outerCrossHex)
        canvas.drawRect(w * 0.28f, 0f, w * 0.44f, h, paint)
        canvas.drawRect(0f, h * 0.36f, w, h * 0.64f, paint)

        if (innerCrossHex != null) {
            paint.color = Color.parseColor(innerCrossHex)
            canvas.drawRect(w * 0.32f, 0f, w * 0.40f, h, paint)
            canvas.drawRect(0f, h * 0.42f, w, h * 0.58f, paint)
        }
    }

    private fun drawUnionJack(canvas: Canvas, w: Float, h: Float, paint: Paint) {
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#012169")
        canvas.drawRect(0f, 0f, w, h, paint)

        paint.color = Color.WHITE
        paint.strokeWidth = h * 0.16f
        canvas.drawLine(0f, 0f, w, h, paint)
        canvas.drawLine(w, 0f, 0f, h, paint)

        paint.color = Color.parseColor("#C8102E")
        paint.strokeWidth = h * 0.08f
        canvas.drawLine(0f, 0f, w, h, paint)
        canvas.drawLine(w, 0f, 0f, h, paint)

        paint.color = Color.WHITE
        canvas.drawRect(w * 0.40f, 0f, w * 0.60f, h, paint)
        canvas.drawRect(0f, h * 0.36f, w, h * 0.64f, paint)

        paint.color = Color.parseColor("#C8102E")
        canvas.drawRect(w * 0.44f, 0f, w * 0.56f, h, paint)
        canvas.drawRect(0f, h * 0.42f, w, h * 0.58f, paint)
    }
}
