package com.srcreationfarm.quickvpn

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Collections
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

object ServerRepository {

    data class ProxyNode(
        val host: String,
        val port: Int,
        val type: String, // "SOCKS5" or "HTTP"
        val latencyMs: Int
    )

    private val nodePool = mutableMapOf<String, MutableList<ProxyNode>>()
    private val failedNodes = Collections.synchronizedSet(mutableSetOf<String>())

    fun markNodeFailed(host: String, port: Int) {
        failedNodes.add("$host:$port")
        synchronized(nodePool) {
            nodePool.values.forEach { list ->
                list.removeAll { it.host == host && it.port == port }
            }
        }
    }

    fun getPoolForCountry(isoCode: String): List<ProxyNode> {
        return synchronized(nodePool) {
            nodePool[isoCode]?.toList() ?: emptyList()
        }
    }

    /**
     * Fetches candidate relays for the exact ISO country code and verifies:
     * 1. TCP & Tunnel establishment (SOCKS5 or HTTP CONNECT)
     * 2. Genuine End-to-End TLS Handshake + Official Google SSL Certificate & Hostname verification
     * This guarantees Chrome will NEVER show "Your connection is not private" or "ERR_EMPTY_RESPONSE"!
     */
    fun fetchAndVerifyNodeForCountry(
        isoCode: String,
        forceNext: Boolean = false,
        onResult: (ProxyNode?) -> Unit
    ) {
        Thread {
            val cached = getPoolForCountry(isoCode)
            if (cached.isNotEmpty()) {
                val ordered = if (forceNext && cached.size > 1) {
                    cached.drop(1) + cached.take(1)
                } else {
                    cached
                }
                for (node in ordered) {
                    if (failedNodes.contains("${node.host}:${node.port}")) continue
                    val rtt = verifyRealTlsTunnel(node.host, node.port, node.type, 4500)
                    if (rtt > 0) {
                        val updated = node.copy(latencyMs = rtt)
                        synchronized(nodePool) {
                            val list = nodePool.getOrPut(isoCode) { mutableListOf() }
                            list.removeAll { it.host == node.host && it.port == node.port }
                            list.add(0, updated)
                        }
                        onResult(updated)
                        return@Thread
                    } else {
                        markNodeFailed(node.host, node.port)
                    }
                }
            }

            val candidates = LinkedHashSet<Triple<String, Int, String>>()

            // Priority 1: SOCKS5 proxies (SOCKS5 is a pure layer-5 TCP relay and never intercepts TLS certificates)
            try {
                val urlStr =
                    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=4000&country=$isoCode"
                httpGet(urlStr, 5000).lines().forEach { line ->
                    val parts = line.trim().split(":")
                    if (parts.size == 2) {
                        val p = parts[1].toIntOrNull()
                        if (p != null && p in 1..65535 && !failedNodes.contains("${parts[0]}:$p")) {
                            candidates.add(Triple(parts[0], p, "SOCKS5"))
                        }
                    }
                }
            } catch (_: Exception) {
            }

            // Priority 2: GeoNode SOCKS5 & Elite HTTPS proxies
            try {
                val geoUrl =
                    "https://proxylist.geonode.com/api/proxy-list?country=$isoCode&limit=35&page=1&sort_by=lastChecked&sort_type=desc&protocols=socks5%2Chttp"
                val jsonStr = httpGet(geoUrl, 5500)
                if (jsonStr.isNotEmpty()) {
                    val root = JSONObject(jsonStr)
                    val data = root.optJSONArray("data")
                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val item = data.getJSONObject(i)
                            val ip = item.optString("ip")
                            val port = item.optString("port").toIntOrNull() ?: 0
                            val protocols = item.optJSONArray("protocols")
                            val proto = if (protocols != null && protocols.length() > 0) {
                                protocols.getString(0).uppercase()
                            } else {
                                "HTTP"
                            }
                            if (ip.isNotEmpty() && port > 0 && !failedNodes.contains("$ip:$port")) {
                                val mappedType = if (proto.contains("SOCKS")) "SOCKS5" else "HTTP"
                                candidates.add(Triple(ip, port, mappedType))
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }

            // Priority 3: ProxyScrape Elite SSL-enabled HTTP proxies
            try {
                val urlStr =
                    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=4000&country=$isoCode&ssl=yes&anonymity=elite"
                httpGet(urlStr, 5000).lines().forEach { line ->
                    val parts = line.trim().split(":")
                    if (parts.size == 2) {
                        val p = parts[1].toIntOrNull()
                        if (p != null && p in 1..65535 && !failedNodes.contains("${parts[0]}:$p")) {
                            candidates.add(Triple(parts[0], p, "HTTP"))
                        }
                    }
                }
            } catch (_: Exception) {
            }

            if (candidates.isEmpty()) {
                onResult(null)
                return@Thread
            }

            // Verify candidates concurrently with FULL TLS Certificate & SNI validation!
            val subset = candidates.take(40)
            val executor = Executors.newFixedThreadPool(12)
            val verified = Collections.synchronizedList(mutableListOf<ProxyNode>())

            for ((host, port, type) in subset) {
                executor.submit {
                    val rtt = verifyRealTlsTunnel(host, port, type, 4500)
                    if (rtt > 0) {
                        verified.add(ProxyNode(host, port, type, rtt))
                    } else {
                        failedNodes.add("$host:$port")
                    }
                }
            }
            executor.shutdown()
            try {
                executor.awaitTermination(9, TimeUnit.SECONDS)
            } catch (_: Exception) {
            }

            // Prefer SOCKS5 first, then lowest latency
            val sorted = verified.sortedWith(
                compareBy<ProxyNode> { if (it.type == "SOCKS5") 0 else 1 }
                    .thenBy { it.latencyMs }
            )
            if (sorted.isNotEmpty()) {
                synchronized(nodePool) {
                    nodePool[isoCode] = sorted.toMutableList()
                }
                onResult(sorted.first())
            } else {
                onResult(null)
            }
        }.start()
    }

    /**
     * Performs a complete end-to-end TLS handshake over the tunnel and validates the
     * peer SSL certificate against Android's system CA store for www.google.com.
     * Rejects any MITM / captive portal / self-signed certificate proxy!
     */
    fun verifyRealTlsTunnel(host: String, port: Int, type: String, timeoutMs: Int): Int {
        var rawSocket: Socket? = null
        var sslSocket: SSLSocket? = null
        return try {
            val start = System.currentTimeMillis()
            rawSocket = Socket()
            rawSocket.connect(InetSocketAddress(host, port), timeoutMs)
            rawSocket.soTimeout = timeoutMs

            val input = rawSocket.getInputStream()
            val output = rawSocket.getOutputStream()

            val tunnelReady = if (type == "SOCKS5") {
                testSocks5Connect(input, output, "www.google.com", 443)
            } else {
                testHttpConnect(input, output, "www.google.com", 443)
            }

            if (!tunnelReady) {
                return -1
            }

            // Upgrade tunnel to TLS and verify genuine Google SSL certificate chain
            val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
            sslSocket = factory.createSocket(
                rawSocket,
                "www.google.com",
                443,
                true
            ) as SSLSocket
            sslSocket.soTimeout = timeoutMs
            sslSocket.startHandshake()

            val hostnameValid = HttpsURLConnection.getDefaultHostnameVerifier()
                .verify("www.google.com", sslSocket.session)

            if (!hostnameValid) {
                return -1
            }

            // Send lightweight HTTP HEAD request over verified TLS tunnel to confirm clean data transfer
            val sslOut = sslSocket.getOutputStream()
            val sslIn = sslSocket.getInputStream()
            val headReq = "HEAD /generate_204 HTTP/1.1\r\nHost: www.google.com\r\nConnection: close\r\n\r\n"
            sslOut.write(headReq.toByteArray(StandardCharsets.ISO_8859_1))
            sslOut.flush()

            val respBuf = ByteArray(32)
            val n = sslIn.read(respBuf)
            if (n <= 0) {
                return -1
            }

            val respStart = String(respBuf, 0, n, StandardCharsets.ISO_8859_1)
            if (respStart.startsWith("HTTP/1.") || respStart.startsWith("HTTP/2")) {
                (System.currentTimeMillis() - start).toInt().coerceAtLeast(1)
            } else {
                -1
            }
        } catch (_: Exception) {
            -1
        } finally {
            try {
                sslSocket?.close()
            } catch (_: Exception) {
            }
            try {
                rawSocket?.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun testHttpConnect(
        input: InputStream,
        output: OutputStream,
        targetHost: String,
        targetPort: Int
    ): Boolean {
        val req = "CONNECT $targetHost:$targetPort HTTP/1.1\r\n" +
            "Host: $targetHost:$targetPort\r\n" +
            "Proxy-Connection: keep-alive\r\n\r\n"
        output.write(req.toByteArray(StandardCharsets.ISO_8859_1))
        output.flush()

        val statusLine = readLineAscii(input)
        if (!statusLine.startsWith("HTTP/1.") || !statusLine.contains(" 200")) {
            return false
        }
        // Drain remaining response headers up to empty line (\r\n)
        while (true) {
            val headerLine = readLineAscii(input)
            if (headerLine.isEmpty()) break
        }
        return true
    }

    private fun readLineAscii(input: InputStream): String {
        val sb = StringBuilder()
        while (sb.length < 1024) {
            val b = input.read()
            if (b == -1) break
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun testSocks5Connect(
        input: InputStream,
        output: OutputStream,
        targetHost: String,
        targetPort: Int
    ): Boolean {
        output.write(byteArrayOf(0x05, 0x01, 0x00))
        output.flush()
        val greet = ByteArray(2)
        if (readExact(input, greet) != 2 || greet[0] != 0x05.toByte() || greet[1] != 0x00.toByte()) {
            return false
        }

        val hostBytes = targetHost.toByteArray(StandardCharsets.UTF_8)
        val req = ByteArray(7 + hostBytes.size)
        req[0] = 0x05
        req[1] = 0x01
        req[2] = 0x00
        req[3] = 0x03
        req[4] = hostBytes.size.toByte()
        System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
        req[5 + hostBytes.size] = ((targetPort shr 8) and 0xFF).toByte()
        req[6 + hostBytes.size] = (targetPort and 0xFF).toByte()
        output.write(req)
        output.flush()

        val head = ByteArray(4)
        if (readExact(input, head) != 4 || head[1] != 0x00.toByte()) {
            return false
        }
        val skipLen = when (head[3].toInt() and 0xFF) {
            0x01 -> 4 + 2
            0x04 -> 16 + 2
            0x03 -> {
                val lenByte = input.read()
                if (lenByte < 0) return false
                lenByte + 2
            }
            else -> return false
        }
        val discard = ByteArray(skipLen)
        return readExact(input, discard) == skipLen
    }

    private fun readExact(input: InputStream, buf: ByteArray): Int {
        var offset = 0
        while (offset < buf.size) {
            val n = input.read(buf, offset, buf.size - offset)
            if (n <= 0) return offset
            offset += n
        }
        return offset
    }

    private fun httpGet(urlStr: String, timeoutMs: Int): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            requestMethod = "GET"
            setRequestProperty("User-Agent", "QuickConnectVPN/1.6.0")
        }
        return try {
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            } else {
                ""
            }
        } finally {
            conn.disconnect()
        }
    }
}
