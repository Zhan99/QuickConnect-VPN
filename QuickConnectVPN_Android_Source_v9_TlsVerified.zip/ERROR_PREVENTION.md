# Permanent Error Prevention Log - SR Creation Farm

- **Browser SSL Warning ("Your connection is not private" on HTTPS sites)**:
  - **Root Cause:** Some public HTTP proxies return `200 Connection established` on `CONNECT www.google.com:443` and then perform TLS interception with a self-signed or invalid SSL certificate, causing Chrome to block the connection with `Your connection is not private`.
  - **Affected File:** `app/src/main/java/com/srcreationfarm/quickvpn/ServerRepository.kt`
  - **Correct Solution:** Updated `verifyRealTlsTunnel()` to wrap the established tunnel socket in `SSLSocketFactory`, execute `sslSocket.startHandshake()`, validate `HttpsURLConnection.getDefaultHostnameVerifier().verify("www.google.com", sslSocket.session)`, and verify a `HEAD /generate_204` response over TLS before accepting any server. Also prioritized `SOCKS5` nodes over `HTTP` proxies.
  - **Verification Status:** Verified all Kotlin/XML syntax and ZIP archive integrity.
