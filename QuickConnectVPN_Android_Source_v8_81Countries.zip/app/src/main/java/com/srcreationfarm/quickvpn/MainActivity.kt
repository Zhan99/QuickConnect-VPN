package com.srcreationfarm.quickvpn

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.srcreationfarm.quickvpn.databinding.ActivityMainBinding
import com.srcreationfarm.quickvpn.databinding.DialogInfoBinding
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ServerAdapter
    private lateinit var serverList: MutableList<ServerLocation>

    private var selectedServerId: String = "us_east"
    private var isConnecting: Boolean = false

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            requestBatteryOptimizationAndStart()
        } else {
            isConnecting = false
            Toast.makeText(this, "VPN permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    private val batteryOptLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        fetchNodeAndStartVpn(forceNext = false)
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        prepareAndStartVpn()
    }

    private val vpnStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val connected = intent?.getBooleanExtra(QuickVpnService.EXTRA_IS_CONNECTED, false) ?: false
            val serverName = intent?.getStringExtra(QuickVpnService.EXTRA_COUNTRY_NAME) ?: ""
            val errorMsg = intent?.getStringExtra(QuickVpnService.EXTRA_ERROR_MSG)
            isConnecting = false
            updateConnectionUi(connected, serverName)
            if (!errorMsg.isNullOrBlank()) {
                Toast.makeText(this@MainActivity, errorMsg, Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
        selectedServerId = prefs.getString("selected_server_id", "us_east") ?: "us_east"

        initServers()
        loadSavedCustomProxies()
        setupRecyclerView()
        setupClickListeners()
        updateConnectionUi(QuickVpnService.isConnected, QuickVpnService.activeServerName)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(QuickVpnService.ACTION_VPN_STATE_CHANGED)
        ContextCompat.registerReceiver(
            this,
            vpnStateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        updateConnectionUi(QuickVpnService.isConnected, QuickVpnService.activeServerName)
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(vpnStateReceiver)
        } catch (_: Exception) {
        }
    }

    private fun initServers() {
        // First 15 match exact screenshot order, followed by 60+ global free/fast VPN countries
        serverList = mutableListOf(
            ServerLocation("sg", "Singapore", "SG", "SG", "10.8.1.2"),
            ServerLocation("in", "India", "IN", "IN", "10.8.2.2"),
            ServerLocation("kr", "South Korea", "KR", "KR", "10.8.3.2"),
            ServerLocation("au", "Australia", "AU", "AU", "10.8.4.2"),
            ServerLocation("jp", "Japan", "JP", "JP", "10.8.5.2"),
            ServerLocation("us_east", "US East", "US_EAST", "US", "10.8.6.2"),
            ServerLocation("us_west", "US West", "US_WEST", "US", "10.8.7.2"),
            ServerLocation("ca", "Canada", "CA", "CA", "10.8.8.2"),
            ServerLocation("de", "Germany", "DE", "DE", "10.8.9.2"),
            ServerLocation("gb", "UK", "GB", "GB", "10.8.10.2"),
            ServerLocation("nl", "Netherlands", "NL", "NL", "10.8.11.2"),
            ServerLocation("es", "Spain", "ES", "ES", "10.8.12.2"),
            ServerLocation("fr", "France", "FR", "FR", "10.8.13.2"),
            ServerLocation("it", "Italy", "IT", "IT", "10.8.14.2"),
            ServerLocation("se", "Sweden", "SE", "SE", "10.8.15.2"),
            // Asia & Oceania
            ServerLocation("hk", "Hong Kong", "HK", "HK", "10.8.16.2"),
            ServerLocation("tw", "Taiwan", "TW", "TW", "10.8.17.2"),
            ServerLocation("id", "Indonesia", "ID", "ID", "10.8.18.2"),
            ServerLocation("my", "Malaysia", "MY", "MY", "10.8.19.2"),
            ServerLocation("th", "Thailand", "TH", "TH", "10.8.20.2"),
            ServerLocation("vn", "Vietnam", "VN", "VN", "10.8.21.2"),
            ServerLocation("ph", "Philippines", "PH", "PH", "10.8.22.2"),
            ServerLocation("cn", "China", "CN", "CN", "10.8.23.2"),
            ServerLocation("pk", "Pakistan", "PK", "PK", "10.8.24.2"),
            ServerLocation("bd", "Bangladesh", "BD", "BD", "10.8.25.2"),
            ServerLocation("np", "Nepal", "NP", "NP", "10.8.26.2"),
            ServerLocation("kz", "Kazakhstan", "KZ", "KZ", "10.8.27.2"),
            ServerLocation("nz", "New Zealand", "NZ", "NZ", "10.8.28.2"),
            // Europe
            ServerLocation("ch", "Switzerland", "CH", "CH", "10.8.29.2"),
            ServerLocation("at", "Austria", "AT", "AT", "10.8.30.2"),
            ServerLocation("be", "Belgium", "BE", "BE", "10.8.31.2"),
            ServerLocation("ie", "Ireland", "IE", "IE", "10.8.32.2"),
            ServerLocation("pt", "Portugal", "PT", "PT", "10.8.33.2"),
            ServerLocation("pl", "Poland", "PL", "PL", "10.8.34.2"),
            ServerLocation("cz", "Czech Republic", "CZ", "CZ", "10.8.35.2"),
            ServerLocation("no", "Norway", "NO", "NO", "10.8.36.2"),
            ServerLocation("dk", "Denmark", "DK", "DK", "10.8.37.2"),
            ServerLocation("fi", "Finland", "FI", "FI", "10.8.38.2"),
            ServerLocation("is", "Iceland", "IS", "IS", "10.8.39.2"),
            ServerLocation("gr", "Greece", "GR", "GR", "10.8.40.2"),
            ServerLocation("ro", "Romania", "RO", "RO", "10.8.41.2"),
            ServerLocation("bg", "Bulgaria", "BG", "BG", "10.8.42.2"),
            ServerLocation("hu", "Hungary", "HU", "HU", "10.8.43.2"),
            ServerLocation("sk", "Slovakia", "SK", "SK", "10.8.44.2"),
            ServerLocation("si", "Slovenia", "SI", "SI", "10.8.45.2"),
            ServerLocation("hr", "Croatia", "HR", "HR", "10.8.46.2"),
            ServerLocation("rs", "Serbia", "RS", "RS", "10.8.47.2"),
            ServerLocation("al", "Albania", "AL", "AL", "10.8.48.2"),
            ServerLocation("ua", "Ukraine", "UA", "UA", "10.8.49.2"),
            ServerLocation("ru", "Russia", "RU", "RU", "10.8.50.2"),
            ServerLocation("md", "Moldova", "MD", "MD", "10.8.51.2"),
            ServerLocation("ee", "Estonia", "EE", "EE", "10.8.52.2"),
            ServerLocation("lv", "Latvia", "LV", "LV", "10.8.53.2"),
            ServerLocation("lt", "Lithuania", "LT", "LT", "10.8.54.2"),
            ServerLocation("lu", "Luxembourg", "LU", "LU", "10.8.55.2"),
            ServerLocation("cy", "Cyprus", "CY", "CY", "10.8.56.2"),
            ServerLocation("ge", "Georgia", "GE", "GE", "10.8.57.2"),
            ServerLocation("am", "Armenia", "AM", "AM", "10.8.58.2"),
            ServerLocation("az", "Azerbaijan", "AZ", "AZ", "10.8.59.2"),
            // Americas
            ServerLocation("br", "Brazil", "BR", "BR", "10.8.60.2"),
            ServerLocation("mx", "Mexico", "MX", "MX", "10.8.61.2"),
            ServerLocation("ar", "Argentina", "AR", "AR", "10.8.62.2"),
            ServerLocation("cl", "Chile", "CL", "CL", "10.8.63.2"),
            ServerLocation("co", "Colombia", "CO", "CO", "10.8.64.2"),
            ServerLocation("pe", "Peru", "PE", "PE", "10.8.65.2"),
            ServerLocation("ec", "Ecuador", "EC", "EC", "10.8.66.2"),
            ServerLocation("ve", "Venezuela", "VE", "VE", "10.8.67.2"),
            ServerLocation("bo", "Bolivia", "BO", "BO", "10.8.68.2"),
            ServerLocation("py", "Paraguay", "PY", "PY", "10.8.69.2"),
            // Middle East & Africa
            ServerLocation("ae", "UAE", "AE", "AE", "10.8.70.2"),
            ServerLocation("sa", "Saudi Arabia", "SA", "SA", "10.8.71.2"),
            ServerLocation("qa", "Qatar", "QA", "QA", "10.8.72.2"),
            ServerLocation("tr", "Turkey", "TR", "TR", "10.8.73.2"),
            ServerLocation("il", "Israel", "IL", "IL", "10.8.74.2"),
            ServerLocation("iq", "Iraq", "IQ", "IQ", "10.8.75.2"),
            ServerLocation("ir", "Iran", "IR", "IR", "10.8.76.2"),
            ServerLocation("eg", "Egypt", "EG", "EG", "10.8.77.2"),
            ServerLocation("za", "South Africa", "ZA", "ZA", "10.8.78.2"),
            ServerLocation("ng", "Nigeria", "NG", "NG", "10.8.79.2"),
            ServerLocation("gh", "Ghana", "GH", "GH", "10.8.80.2"),
            ServerLocation("ci", "Ivory Coast", "CI", "CI", "10.8.81.2")
        )
    }

    private fun loadSavedCustomProxies() {
        val prefs = getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
        for (server in serverList) {
            val host = prefs.getString("custom_host_${server.id}", "") ?: ""
            val port = prefs.getInt("custom_port_${server.id}", 0)
            val type = prefs.getString("custom_type_${server.id}", "HTTP") ?: "HTTP"
            if (host.isNotEmpty() && port > 0) {
                server.proxyHost = host
                server.proxyPort = port
                server.proxyType = type
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = ServerAdapter(serverList, selectedServerId) { server ->
            selectedServerId = server.id
            getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
                .edit()
                .putString("selected_server_id", selectedServerId)
                .apply()
            adapter.setSelectedServer(selectedServerId)

            if (QuickVpnService.isConnected) {
                fetchNodeAndStartVpn(forceNext = false)
            }
        }
        binding.rvServers.layoutManager = LinearLayoutManager(this)
        binding.rvServers.adapter = adapter
    }

    private fun setupClickListeners() {
        binding.fabConnect.setOnClickListener {
            if (isConnecting) return@setOnClickListener
            if (QuickVpnService.isConnected) {
                disconnectVpn()
            } else {
                checkPermissionsAndConnect()
            }
        }

        binding.btnInfo.setOnClickListener {
            showInfoDialog()
        }
    }

    private fun checkPermissionsAndConnect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        prepareAndStartVpn()
    }

    private fun prepareAndStartVpn() {
        try {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                vpnPermissionLauncher.launch(intent)
            } else {
                requestBatteryOptimizationAndStart()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "VPN not supported on this device", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryOptimizationAndStart() {
        val prefs = getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
        val alreadyAsked = prefs.getBoolean("asked_battery_opt", false)
        val pm = getSystemService(PowerManager::class.java)

        if (!alreadyAsked && pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
            prefs.edit().putBoolean("asked_battery_opt", true).apply()
            try {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                batteryOptLauncher.launch(intent)
                return
            } catch (_: Exception) {
            }
        }
        fetchNodeAndStartVpn(forceNext = false)
    }

    private fun fetchNodeAndStartVpn(forceNext: Boolean) {
        val server = getSelectedServer()
        isConnecting = true
        binding.tvConnectionStatus.visibility = View.VISIBLE
        binding.tvConnectionStatus.text = "Testing ${server.countryName} tunnel..."
        Toast.makeText(
            this,
            "Verifying active ${server.countryName} tunnel...",
            Toast.LENGTH_SHORT
        ).show()

        if (!forceNext && server.proxyHost.isNotEmpty() && server.proxyPort > 0) {
            thread {
                val rtt = ServerRepository.verifyRealTunnel(
                    server.proxyHost,
                    server.proxyPort,
                    server.proxyType,
                    3500
                )
                runOnUiThread {
                    if (rtt > 0) {
                        server.latencyMs = rtt
                        server.signalLevel = latencyToSignal(rtt)
                        adapter.setShowPing(true)
                        startVpnServiceWithNode(server, server.proxyHost, server.proxyPort, server.proxyType)
                    } else {
                        ServerRepository.markNodeFailed(server.proxyHost, server.proxyPort)
                        discoverAndConnect(server, forceNext = true)
                    }
                }
            }
        } else {
            discoverAndConnect(server, forceNext = forceNext)
        }
    }

    private fun discoverAndConnect(server: ServerLocation, forceNext: Boolean) {
        ServerRepository.fetchAndVerifyNodeForCountry(server.isoCode, forceNext) { node ->
            runOnUiThread {
                if (node != null) {
                    server.proxyHost = node.host
                    server.proxyPort = node.port
                    server.proxyType = node.type
                    server.latencyMs = node.latencyMs
                    server.signalLevel = latencyToSignal(node.latencyMs)
                    adapter.setShowPing(true)
                    startVpnServiceWithNode(server, node.host, node.port, node.type)
                } else {
                    isConnecting = false
                    updateConnectionUi(QuickVpnService.isConnected, QuickVpnService.activeServerName)
                    Toast.makeText(
                        this,
                        "No live HTTPS tunnel responded for ${server.countryName}. Try another country or Custom Proxy in (i).",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun startVpnServiceWithNode(
        server: ServerLocation,
        proxyHost: String,
        proxyPort: Int,
        proxyType: String
    ) {
        try {
            val serviceIntent = Intent(this, QuickVpnService::class.java).apply {
                action = QuickVpnService.ACTION_CONNECT
                putExtra(QuickVpnService.EXTRA_COUNTRY_NAME, server.countryName)
                putExtra(QuickVpnService.EXTRA_ISO_CODE, server.isoCode)
                putExtra(QuickVpnService.EXTRA_PROXY_HOST, proxyHost)
                putExtra(QuickVpnService.EXTRA_PROXY_PORT, proxyPort)
                putExtra(QuickVpnService.EXTRA_PROXY_TYPE, proxyType)
                putExtra(QuickVpnService.EXTRA_VIRTUAL_IP, server.virtualIp)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
        } catch (e: Exception) {
            isConnecting = false
            Toast.makeText(this, "Failed to start VPN: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun disconnectVpn() {
        try {
            val serviceIntent = Intent(this, QuickVpnService::class.java).apply {
                action = QuickVpnService.ACTION_DISCONNECT
            }
            startService(serviceIntent)
            isConnecting = false
            updateConnectionUi(false, "")
            Toast.makeText(this, "Disconnected", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            isConnecting = false
            updateConnectionUi(false, "")
        }
    }

    private fun updateConnectionUi(connected: Boolean, serverName: String) {
        if (connected) {
            binding.tvConnectionStatus.visibility = View.VISIBLE
            binding.tvConnectionStatus.text = "Connected • $serverName"
            binding.fabConnect.setImageResource(R.drawable.ic_check)
            binding.fabConnect.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.green_connected)
            )
        } else if (!isConnecting) {
            binding.tvConnectionStatus.visibility = View.GONE
            binding.fabConnect.setImageResource(R.drawable.ic_arrow_up)
            binding.fabConnect.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.pink_accent)
            )
        }
    }

    private fun latencyToSignal(ms: Int): Int {
        return when {
            ms < 250 -> 4
            ms < 500 -> 3
            ms < 900 -> 2
            else -> 1
        }
    }

    private fun getSelectedServer(): ServerLocation {
        return serverList.find { it.id == selectedServerId } ?: serverList[5]
    }

    @SuppressLint("BatteryLife")
    private fun showInfoDialog() {
        val dialogBinding = DialogInfoBinding.inflate(layoutInflater)
        val server = getSelectedServer()
        val statusText = if (QuickVpnService.isConnected) {
            "Connected (${QuickVpnService.activeServerName})"
        } else {
            "Disconnected"
        }
        val endpointText = if (QuickVpnService.activeProxyEndpoint.isNotEmpty()) {
            QuickVpnService.activeProxyEndpoint
        } else if (server.proxyHost.isNotEmpty()) {
            "${server.proxyHost}:${server.proxyPort} (${server.proxyType})"
        } else {
            "Auto-verify on Connect"
        }

        val pm = getSystemService(PowerManager::class.java)
        val isBatteryIgnored = pm?.isIgnoringBatteryOptimizations(packageName) == true

        dialogBinding.tvDialogServerStatus.text =
            "Global Countries: ${serverList.size} Locations\n" +
            "Selected Location: ${server.countryName} (${server.isoCode})\n" +
            "Connection Status: $statusText\n" +
            "Verified Relay: $endpointText"

        dialogBinding.btnBatteryOpt.text = if (isBatteryIgnored) {
            "Battery: Unrestricted ✓"
        } else {
            "Unrestrict Battery"
        }

        dialogBinding.btnBatteryOpt.setOnClickListener {
            try {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } catch (_: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {
                }
            }
        }

        dialogBinding.btnRefreshPing.setOnClickListener {
            dialogBinding.btnRefreshPing.isEnabled = false
            dialogBinding.btnRefreshPing.text = "Switching..."
            ServerRepository.fetchAndVerifyNodeForCountry(server.isoCode, forceNext = true) { node ->
                runOnUiThread {
                    dialogBinding.btnRefreshPing.isEnabled = true
                    dialogBinding.btnRefreshPing.text = "Switch Node"
                    if (node != null) {
                        server.proxyHost = node.host
                        server.proxyPort = node.port
                        server.proxyType = node.type
                        server.latencyMs = node.latencyMs
                        server.signalLevel = latencyToSignal(node.latencyMs)
                        adapter.setShowPing(true)
                        dialogBinding.tvDialogServerStatus.text =
                            "Global Countries: ${serverList.size} Locations\n" +
                            "Selected Location: ${server.countryName} (${server.isoCode})\n" +
                            "Connection Status: $statusText\n" +
                            "Verified Relay: ${node.host}:${node.port} (${node.latencyMs}ms)"
                        if (QuickVpnService.isConnected) {
                            startVpnServiceWithNode(server, node.host, node.port, node.type)
                        }
                        Toast.makeText(
                            this,
                            "Switched to ${server.countryName} node: ${node.host} (${node.latencyMs}ms)",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(
                            this,
                            "No alternate live node for ${server.countryName}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }

        dialogBinding.btnCheckIp.setOnClickListener {
            dialogBinding.btnCheckIp.isEnabled = false
            dialogBinding.btnCheckIp.text = "Checking..."
            checkCurrentPublicIp(server) { ipResult ->
                runOnUiThread {
                    dialogBinding.btnCheckIp.isEnabled = true
                    dialogBinding.btnCheckIp.text = "Check My IP"
                    dialogBinding.tvDialogServerStatus.text =
                        "Selected Location: ${server.countryName} (${server.isoCode})\n" +
                        "Connection Status: $statusText\n" +
                        "Verified Relay: $endpointText\n" +
                        "$ipResult"
                }
            }
        }

        dialogBinding.btnCustomProxy.setOnClickListener {
            showCustomProxyDialog(server)
        }

        dialogBinding.btnYoutube.setOnClickListener {
            openExternalUrl(getString(R.string.youtube_url))
        }

        dialogBinding.btnFacebook.setOnClickListener {
            openExternalUrl(getString(R.string.facebook_url))
        }

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showCustomProxyDialog(server: ServerLocation) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 12)
        }
        val etHost = EditText(this).apply {
            hint = "Proxy IP / Host (e.g. 198.51.100.10)"
            setText(server.proxyHost)
        }
        val etPort = EditText(this).apply {
            hint = "Port (e.g. 8080 or 1080)"
            inputType = InputType.TYPE_CLASS_NUMBER
            if (server.proxyPort > 0) setText(server.proxyPort.toString())
        }
        val rgType = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
        }
        val rbHttp = RadioButton(this).apply {
            text = "HTTP/HTTPS"
            id = View.generateViewId()
        }
        val rbSocks = RadioButton(this).apply {
            text = "SOCKS5"
            id = View.generateViewId()
        }
        rgType.addView(rbHttp)
        rgType.addView(rbSocks)
        if (server.proxyType == "SOCKS5") rbSocks.isChecked = true else rbHttp.isChecked = true

        layout.addView(etHost)
        layout.addView(etPort)
        layout.addView(rgType)

        AlertDialog.Builder(this)
            .setTitle("Custom ${server.countryName} Proxy")
            .setView(layout)
            .setPositiveButton("Save & Connect") { _, _ ->
                val host = etHost.text.toString().trim()
                val port = etPort.text.toString().trim().toIntOrNull() ?: 0
                val type = if (rbSocks.isChecked) "SOCKS5" else "HTTP"
                if (host.isNotEmpty() && port in 1..65535) {
                    server.proxyHost = host
                    server.proxyPort = port
                    server.proxyType = type
                    getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
                        .edit()
                        .putString("custom_host_${server.id}", host)
                        .putInt("custom_port_${server.id}", port)
                        .putString("custom_type_${server.id}", type)
                        .apply()
                    fetchNodeAndStartVpn(forceNext = false)
                } else {
                    Toast.makeText(this, "Invalid IP or Port", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Clear") { _, _ ->
                server.proxyHost = ""
                server.proxyPort = 0
                getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
                    .edit()
                    .remove("custom_host_${server.id}")
                    .remove("custom_port_${server.id}")
                    .apply()
                Toast.makeText(this, "Cleared custom proxy", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun checkCurrentPublicIp(server: ServerLocation, onResult: (String) -> Unit) {
        thread {
            val res = try {
                val url = URL("http://ip-api.com/json/?fields=status,country,city,isp,query")
                val conn = if (QuickVpnService.isConnected && server.proxyHost.isNotEmpty() && server.proxyPort > 0) {
                    val pType = if (server.proxyType == "SOCKS5") Proxy.Type.SOCKS else Proxy.Type.HTTP
                    val proxy = Proxy(pType, InetSocketAddress(server.proxyHost, server.proxyPort))
                    url.openConnection(proxy) as HttpURLConnection
                } else {
                    url.openConnection() as HttpURLConnection
                }
                conn.connectTimeout = 6000
                conn.readTimeout = 6000
                val body = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                conn.disconnect()
                val json = JSONObject(body)
                if (json.optString("status") == "success") {
                    "Public IP: ${json.optString("query")}\nCountry: ${json.optString("country")} (${json.optString("city")})\nISP: ${json.optString("isp")}"
                } else {
                    "Public IP: Unable to parse"
                }
            } catch (e: Exception) {
                "Public IP: Timeout (${e.message}) — Tap 'Switch Node'"
            }
            onResult(res)
        }
    }

    private fun openExternalUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to open link", Toast.LENGTH_SHORT).show()
        }
    }
}
