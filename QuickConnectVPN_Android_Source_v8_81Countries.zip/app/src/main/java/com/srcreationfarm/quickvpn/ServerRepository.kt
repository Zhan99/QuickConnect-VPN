package com.srcreationfarm.quickvpn

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Collections
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object ServerRepository {

    data class ProxyNode(
        val host: String,
        val port: Int,
        val type: String, // "HTTP" or "SOCKS5"
        val latencyMs: Int
    )

    private val nodePool = mutableMapOf<String, MutableList<ProxyNode>>()
    private val failedNodes = Collections.synchronizedSet(mutableSetOf<String>())

    fun markNodeFailed(host: String, port: Int) {
        failedNodes.add("$host:$port")
        synchronized(nodePool) {
            nodePool.values.forEach { list ->
                list.removeAll { it.host == host && it.port == port }
            }
        }
    }

    fun getPoolForCountry(isoCode: String): List<ProxyNode> {
        return synchronized(nodePool) {
            nodePool[isoCode]?.toList() ?: emptyList()
        }
    }

    fun fetchAndVerifyNodeForCountry(
        isoCode: String,
        forceNext: Boolean = false,
        onResult: (ProxyNode?) -> Unit
    ) {
        Thread {
            val cached = getPoolForCountry(isoCode)
            if (cached.isNotEmpty()) {
                val ordered = if (forceNext && cached.size > 1) {
                    cached.drop(1) + cached.take(1)
                } else {
                    cached
                }
                for (node in ordered) {
                    if (failedNodes.contains("${node.host}:${node.port}")) continue
                    val rtt = verifyRealTunnel(node.host, node.port, node.type, 3500)
                    if (rtt > 0) {
                        val updated = node.copy(latencyMs = rtt)
                        synchronized(nodePool) {
                            val list = nodePool.getOrPut(isoCode) { mutableListOf() }
                            list.removeAll { it.host == node.host && it.port == node.port }
                            list.add(0, updated)
                        }
                        onResult(updated)
                        return@Thread
                    } else {
                        markNodeFailed(node.host, node.port)
                    }
                }
            }

            val candidates = LinkedHashSet<Triple<String, Int, String>>()

            // Source 1: ProxyScrape SOCKS5
            try {
                val urlStr =
                    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=4000&country=$isoCode"
                httpGet(urlStr, 5000).lines().forEach { line ->
                    val parts = line.trim().split(":")
                    if (parts.size == 2) {
                        val p = parts[1].toIntOrNull()
                        if (p != null && p in 1..65535 && !failedNodes.contains("${parts[0]}:$p")) {
                            candidates.add(Triple(parts[0], p, "SOCKS5"))
                        }
                    }
                }
            } catch (_: Exception) {
            }

            // Source 2: ProxyScrape HTTP SSL-enabled proxies
            try {
                val urlStr =
                    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=4000&country=$isoCode&ssl=yes"
                httpGet(urlStr, 5000).lines().forEach { line ->
                    val parts = line.trim().split(":")
                    if (parts.size == 2) {
                        val p = parts[1].toIntOrNull()
                        if (p != null && p in 1..65535 && !failedNodes.contains("${parts[0]}:$p")) {
                            candidates.add(Triple(parts[0], p, "HTTP"))
                        }
                    }
                }
            } catch (_: Exception) {
            }

            // Source 3: GeoNode API (covers 100+ countries worldwide)
            try {
                val geoUrl =
                    "https://proxylist.geonode.com/api/proxy-list?country=$isoCode&limit=30&page=1&sort_by=lastChecked&sort_type=desc&protocols=socks5%2Chttp"
                val jsonStr = httpGet(geoUrl, 5500)
                if (jsonStr.isNotEmpty()) {
                    val root = JSONObject(jsonStr)
                    val data = root.optJSONArray("data")
                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val item = data.getJSONObject(i)
                            val ip = item.optString("ip")
                            val port = item.optString("port").toIntOrNull() ?: 0
                            val protocols = item.optJSONArray("protocols")
                            val proto = if (protocols != null && protocols.length() > 0) {
                                protocols.getString(0).uppercase()
                            } else {
                                "HTTP"
                            }
                            if (ip.isNotEmpty() && port > 0 && !failedNodes.contains("$ip:$port")) {
                                val mappedType = if (proto.contains("SOCKS")) "SOCKS5" else "HTTP"
                                candidates.add(Triple(ip, port, mappedType))
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }

            if (candidates.isEmpty()) {
                onResult(null)
                return@Thread
            }

            val subset = candidates.take(35)
            val executor = Executors.newFixedThreadPool(12)
            val verified = Collections.synchronizedList(mutableListOf<ProxyNode>())

            for ((host, port, type) in subset) {
                executor.submit {
                    val rtt = verifyRealTunnel(host, port, type, 4000)
                    if (rtt > 0) {
                        verified.add(ProxyNode(host, port, type, rtt))
                    } else {
                        failedNodes.add("$host:$port")
                    }
                }
            }
            executor.shutdown()
            try {
                executor.awaitTermination(8, TimeUnit.SECONDS)
            } catch (_: Exception) {
            }

            val sorted = verified.sortedBy { it.latencyMs }
            if (sorted.isNotEmpty()) {
                synchronized(nodePool) {
                    nodePool[isoCode] = sorted.toMutableList()
                }
                onResult(sorted.first())
            } else {
                onResult(null)
            }
        }.start()
    }

    fun verifyRealTunnel(host: String, port: Int, type: String, timeoutMs: Int): Int {
        var socket: Socket? = null
        return try {
            val start = System.currentTimeMillis()
            socket = Socket()
            socket.connect(InetSocketAddress(host, port), timeoutMs)
            socket.soTimeout = timeoutMs

            val input = socket.getInputStream()
            val output = socket.getOutputStream()

            val ok = if (type == "SOCKS5") {
                testSocks5Connect(input, output, "www.google.com", 443)
            } else {
                testHttpConnect(input, output, "www.google.com", 443)
            }

            if (ok) {
                (System.currentTimeMillis() - start).toInt().coerceAtLeast(1)
            } else {
                -1
            }
        } catch (_: Exception) {
            -1
        } finally {
            try {
                socket?.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun testHttpConnect(
        input: InputStream,
        output: OutputStream,
        targetHost: String,
        targetPort: Int
    ): Boolean {
        val req = "CONNECT $targetHost:$targetPort HTTP/1.1\r\n" +
            "Host: $targetHost:$targetPort\r\n" +
            "Proxy-Connection: keep-alive\r\n\r\n"
        output.write(req.toByteArray(StandardCharsets.ISO_8859_1))
        output.flush()

        val lineBuf = StringBuilder()
        while (lineBuf.length < 512) {
            val b = input.read()
            if (b == -1) return false
            if (b == '\n'.code) break
            if (b != '\r'.code) lineBuf.append(b.toChar())
        }
        val statusLine = lineBuf.toString()
        return statusLine.startsWith("HTTP/1.") && statusLine.contains(" 200")
    }

    private fun testSocks5Connect(
        input: InputStream,
        output: OutputStream,
        targetHost: String,
        targetPort: Int
    ): Boolean {
        output.write(byteArrayOf(0x05, 0x01, 0x00))
        output.flush()
        val greet = ByteArray(2)
        if (readExact(input, greet) != 2 || greet[0] != 0x05.toByte() || greet[1] != 0x00.toByte()) {
            return false
        }

        val hostBytes = targetHost.toByteArray(StandardCharsets.UTF_8)
        val req = ByteArray(7 + hostBytes.size)
        req[0] = 0x05
        req[1] = 0x01
        req[2] = 0x00
        req[3] = 0x03
        req[4] = hostBytes.size.toByte()
        System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
        req[5 + hostBytes.size] = ((targetPort shr 8) and 0xFF).toByte()
        req[6 + hostBytes.size] = (targetPort and 0xFF).toByte()
        output.write(req)
        output.flush()

        val head = ByteArray(4)
        return readExact(input, head) == 4 && head[1] == 0x00.toByte()
    }

    private fun readExact(input: InputStream, buf: ByteArray): Int {
        var offset = 0
        while (offset < buf.size) {
            val n = input.read(buf, offset, buf.size - offset)
            if (n <= 0) return offset
            offset += n
        }
        return offset
    }

    private fun httpGet(urlStr: String, timeoutMs: Int): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            requestMethod = "GET"
            setRequestProperty("User-Agent", "QuickConnectVPN/1.5.0")
        }
        return try {
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            } else {
                ""
            }
        } finally {
            conn.disconnect()
        }
    }
}
