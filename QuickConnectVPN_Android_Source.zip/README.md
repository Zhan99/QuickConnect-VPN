# QuickConnect VPN (QuickVPN UI Edition)

Developed by **Shahriar Rahman** | **SR Creation Farm**
- YouTube: https://www.youtube.com/@SRCreation-farm
- Facebook: https://fb.com/srcreation.farm

## Features
- Exact UI replica of the QuickVPN server list screen (Indigo top bar, white info icon, 15 country locations with signal triangles & crisp vector flags, `#A8A8A8` active row selection, yellow-orange scrollbar, and Pink `#FF4081` bottom-right connect FAB).
- Functional Android `VpnService` encrypted DNS tunnel (Cloudflare `1.1.1.1` / Google `8.8.8.8`) without requiring root.
- Live latency ping measurement across all 15 regions.
- Developer & Brand info dialog with direct YouTube and Facebook buttons.
