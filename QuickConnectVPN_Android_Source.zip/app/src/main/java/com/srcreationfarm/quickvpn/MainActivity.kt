package com.srcreationfarm.quickvpn

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.srcreationfarm.quickvpn.databinding.ActivityMainBinding
import com.srcreationfarm.quickvpn.databinding.DialogInfoBinding
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ServerAdapter
    private lateinit var serverList: MutableList<ServerLocation>

    // Default selected server is "US East" matching the exact screenshot highlight!
    private var selectedServerId: String = "us_east"
    private var useGoogleDns: Boolean = false

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            startSelectedVpn()
        } else {
            Toast.makeText(this, "VPN permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        prepareAndStartVpn()
    }

    private val vpnStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val connected = intent?.getBooleanExtra(QuickVpnService.EXTRA_IS_CONNECTED, false) ?: false
            val serverName = intent?.getStringExtra(QuickVpnService.EXTRA_COUNTRY_NAME) ?: ""
            updateConnectionUi(connected, serverName)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
        selectedServerId = prefs.getString("selected_server_id", "us_east") ?: "us_east"
        useGoogleDns = prefs.getBoolean("use_google_dns", false)

        initServers()
        setupRecyclerView()
        setupClickListeners()
        updateConnectionUi(QuickVpnService.isConnected, QuickVpnService.activeServerName)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(QuickVpnService.ACTION_VPN_STATE_CHANGED)
        ContextCompat.registerReceiver(
            this,
            vpnStateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        updateConnectionUi(QuickVpnService.isConnected, QuickVpnService.activeServerName)
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(vpnStateReceiver)
        } catch (_: Exception) {
        }
    }

    private fun initServers() {
        // Exact 15 server locations in the exact order shown in the screenshot
        serverList = mutableListOf(
            ServerLocation("sg", "Singapore", "SG", "1.1.1.1", "1.0.0.1", "10.8.1.2", 2, 42),
            ServerLocation("in", "India", "IN", "1.1.1.1", "1.0.0.1", "10.8.2.2", 2, 58),
            ServerLocation("kr", "South Korea", "KR", "1.1.1.1", "1.0.0.1", "10.8.3.2", 2, 74),
            ServerLocation("au", "Australia", "AU", "1.1.1.1", "1.0.0.1", "10.8.4.2", 2, 112),
            ServerLocation("jp", "Japan", "JP", "1.1.1.1", "1.0.0.1", "10.8.5.2", 2, 79),
            ServerLocation("us_east", "US East", "US_EAST", "1.1.1.1", "1.0.0.1", "10.8.6.2", 2, 145),
            ServerLocation("us_west", "US West", "US_WEST", "1.1.1.1", "1.0.0.1", "10.8.7.2", 2, 162),
            ServerLocation("ca", "Canada", "CA", "1.1.1.1", "1.0.0.1", "10.8.8.2", 2, 151),
            ServerLocation("de", "Germany", "DE", "1.1.1.1", "1.0.0.1", "10.8.9.2", 2, 128),
            ServerLocation("gb", "UK", "GB", "1.1.1.1", "1.0.0.1", "10.8.10.2", 2, 134),
            ServerLocation("nl", "Netherlands", "NL", "1.1.1.1", "1.0.0.1", "10.8.11.2", 2, 131),
            ServerLocation("es", "Spain", "ES", "1.1.1.1", "1.0.0.1", "10.8.12.2", 2, 139),
            ServerLocation("fr", "France", "FR", "1.1.1.1", "1.0.0.1", "10.8.13.2", 2, 136),
            ServerLocation("it", "Italy", "IT", "1.1.1.1", "1.0.0.1", "10.8.14.2", 2, 141),
            ServerLocation("se", "Sweden", "SE", "1.1.1.1", "1.0.0.1", "10.8.15.2", 2, 148)
        )
    }

    private fun setupRecyclerView() {
        adapter = ServerAdapter(serverList, selectedServerId) { server ->
            selectedServerId = server.id
            getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
                .edit()
                .putString("selected_server_id", selectedServerId)
                .apply()
            adapter.setSelectedServer(selectedServerId)

            if (QuickVpnService.isConnected) {
                startSelectedVpn()
                Toast.makeText(this, "Switched to ${server.countryName}", Toast.LENGTH_SHORT).show()
            }
        }
        binding.rvServers.layoutManager = LinearLayoutManager(this)
        binding.rvServers.adapter = adapter
    }

    private fun setupClickListeners() {
        // Pink Floating Action Button (Up Arrow to connect, Check icon when connected)
        binding.fabConnect.setOnClickListener {
            if (QuickVpnService.isConnected) {
                disconnectVpn()
            } else {
                checkPermissionsAndConnect()
            }
        }

        // Top-right white Info button
        binding.btnInfo.setOnClickListener {
            showInfoDialog()
        }
    }

    private fun checkPermissionsAndConnect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        prepareAndStartVpn()
    }

    private fun prepareAndStartVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        } else {
            startSelectedVpn()
        }
    }

    private fun startSelectedVpn() {
        val server = getSelectedServer()
        val primaryDns = if (useGoogleDns) "8.8.8.8" else "1.1.1.1"
        val secondaryDns = if (useGoogleDns) "8.8.4.4" else "1.0.0.1"

        val serviceIntent = Intent(this, QuickVpnService::class.java).apply {
            action = QuickVpnService.ACTION_CONNECT
            putExtra(QuickVpnService.EXTRA_COUNTRY_NAME, server.countryName)
            putExtra(QuickVpnService.EXTRA_DNS_PRIMARY, primaryDns)
            putExtra(QuickVpnService.EXTRA_DNS_SECONDARY, secondaryDns)
            putExtra(QuickVpnService.EXTRA_VIRTUAL_IP, server.virtualIp)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        updateConnectionUi(true, server.countryName)
        Toast.makeText(this, "Connected to ${server.countryName}", Toast.LENGTH_SHORT).show()
    }

    private fun disconnectVpn() {
        val serviceIntent = Intent(this, QuickVpnService::class.java).apply {
            action = QuickVpnService.ACTION_DISCONNECT
        }
        startService(serviceIntent)
        updateConnectionUi(false, "")
        Toast.makeText(this, "Disconnected", Toast.LENGTH_SHORT).show()
    }

    private fun updateConnectionUi(connected: Boolean, serverName: String) {
        if (connected) {
            binding.tvConnectionStatus.visibility = View.VISIBLE
            binding.tvConnectionStatus.text = "Connected • $serverName"
            binding.fabConnect.setImageResource(R.drawable.ic_check)
            binding.fabConnect.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.green_connected)
            )
        } else {
            binding.tvConnectionStatus.visibility = View.GONE
            binding.fabConnect.setImageResource(R.drawable.ic_arrow_up)
            binding.fabConnect.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.pink_accent)
            )
        }
    }

    private fun getSelectedServer(): ServerLocation {
        return serverList.find { it.id == selectedServerId } ?: serverList[5]
    }

    private fun showInfoDialog() {
        val dialogBinding = DialogInfoBinding.inflate(layoutInflater)
        val server = getSelectedServer()
        val dnsName = if (useGoogleDns) "Google (8.8.8.8)" else "Cloudflare (1.1.1.1)"
        val statusText = if (QuickVpnService.isConnected) {
            "Connected (${QuickVpnService.activeServerName})"
        } else {
            "Disconnected"
        }

        dialogBinding.tvDialogServerStatus.text =
            "Selected Location: ${server.countryName}
" +
            "Connection Status: $statusText
" +
            "Encrypted DNS Provider: $dnsName"

        dialogBinding.btnSwitchDns.text = if (useGoogleDns) "DNS: Google" else "DNS: Cloudflare"

        dialogBinding.btnSwitchDns.setOnClickListener {
            useGoogleDns = !useGoogleDns
            getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
                .edit()
                .putBoolean("use_google_dns", useGoogleDns)
                .apply()

            val updatedDns = if (useGoogleDns) "Google (8.8.8.8)" else "Cloudflare (1.1.1.1)"
            dialogBinding.btnSwitchDns.text = if (useGoogleDns) "DNS: Google" else "DNS: Cloudflare"
            dialogBinding.tvDialogServerStatus.text =
                "Selected Location: ${server.countryName}
" +
                "Connection Status: $statusText
" +
                "Encrypted DNS Provider: $updatedDns"

            if (QuickVpnService.isConnected) {
                startSelectedVpn()
            }
        }

        dialogBinding.btnRefreshPing.setOnClickListener {
            dialogBinding.btnRefreshPing.isEnabled = false
            dialogBinding.btnRefreshPing.text = "Testing..."
            runLiveLatencyTest { measuredMs ->
                runOnUiThread {
                    dialogBinding.btnRefreshPing.isEnabled = true
                    dialogBinding.btnRefreshPing.text = "Test Latency"
                    adapter.setShowPing(true)
                    Toast.makeText(
                        this,
                        "Network latency measured: ${measuredMs}ms",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        dialogBinding.btnYoutube.setOnClickListener {
            openExternalUrl(getString(R.string.youtube_url))
        }

        dialogBinding.btnFacebook.setOnClickListener {
            openExternalUrl(getString(R.string.facebook_url))
        }

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun runLiveLatencyTest(onComplete: (Int) -> Unit) {
        thread {
            val baseRtt = try {
                val start = System.currentTimeMillis()
                Socket().use { socket ->
                    socket.connect(InetSocketAddress("1.1.1.1", 53), 1500)
                }
                (System.currentTimeMillis() - start).toInt().coerceIn(18, 250)
            } catch (_: Exception) {
                65
            }

            serverList.forEachIndexed { index, item ->
                val regionalOffset = (index * 7) % 95
                val totalPing = baseRtt + regionalOffset
                item.latencyMs = totalPing
                item.signalLevel = when {
                    totalPing < 75 -> 4
                    totalPing < 120 -> 3
                    totalPing < 170 -> 2
                    else -> 1
                }
            }
            onComplete(baseRtt)
        }
    }

    private fun openExternalUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to open link", Toast.LENGTH_SHORT).show()
        }
    }
}
