# Permanent Error Prevention Log - SR Creation Farm

- **SDK Setup (`tools` package missing)**: Resolved by using `android-actions/setup-android@v4` with explicit `platform-tools`, `platforms;android-35`, and `build-tools;35.0.0`.
- **Gradle & Java Compatibility**: Verified Java 17 + Gradle 8.9 + AGP 8.5.2 + Kotlin 1.9.24 + compileSdk 35.
- **Auto ZIP Extraction**: Configured `.github/workflows/build.yml` to automatically locate, validate, extract, and detect `settings.gradle.kts` root directory without manual extraction.
- **Android 13+ / 14+ Foreground Service & Notification Compatibility**: Declared `FOREGROUND_SERVICE_SPECIAL_USE` with `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` and `ContextCompat.RECEIVER_NOT_EXPORTED` to pass Android Lint and runtime security checks cleanly.
