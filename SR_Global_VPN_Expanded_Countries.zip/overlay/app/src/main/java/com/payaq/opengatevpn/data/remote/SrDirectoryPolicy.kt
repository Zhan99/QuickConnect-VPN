package com.payaq.opengatevpn.data.remote

import com.payaq.opengatevpn.data.model.VpnServer
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** Directory rows are candidates, not proof of a working tunnel. */
internal object SrDirectoryPolicy {
    const val MAX_BYTES = 16 * 1024 * 1024
    private const val MAX_AGE_MS = 6L * 60 * 60 * 1000
    private val countryCode = Regex("[A-Z]{2}")
    private val configPattern = Regex("[A-Za-z0-9+/]+={0,2}")
    private val stamp = Regex("(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})(?:\\.(\\d{1,9}))?Z")
    fun isFresh(value: String, now: Long): Boolean {
        val match = stamp.matchEntire(value) ?: return false
        val normalized = match.groupValues[1] + "." + match.groupValues[2].padEnd(3,'0').take(3) + "Z"
        val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
            isLenient = false; timeZone = TimeZone.getTimeZone("UTC")
        }
        val date = try { format.parse(normalized)?.time ?: return false } catch (_: Exception) { return false }
        return now - date in -300_000L..MAX_AGE_MS
    }
    fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes)
        .joinToString("") { String.format(Locale.US, "%02x", it.toInt() and 255) }
    private fun ipv4(value: String): Boolean = value.split('.').let { parts ->
        parts.size == 4 && parts.all { it.isNotEmpty() && it.length <= 3 && it.all { c -> c in '0'..'9' } && (it.toIntOrNull() ?: -1) in 0..255 }
    }
    // Accept both quoted CSV and the Gate feed's unquoted operator messages.
    private fun fields(line: String): List<String> {
        val out = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
        while (i < line.length) {
            val c = line[i++]
            when {
                c == '"' && quoted && i < line.length && line[i] == '"' -> { cell.append('"'); i++ }
                c == '"' && quoted -> quoted = false
                c == '"' && cell.isEmpty() -> quoted = true
                c == ',' && !quoted -> { out.add(cell.toString()); cell.setLength(0) }
                else -> cell.append(c)
            }
        }
        if (quoted) return emptyList()
        out.add(cell.toString()); return out
    }
    fun parse(csv: String, configValid: (String) -> Boolean): List<VpnServer> {
        val lines = csv.trimStart('\uFEFF').lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        require(lines.firstOrNull() == "*vpn_servers" && lines.lastOrNull() == "*") { "Incomplete VPN Gate feed" }
        require(lines.any { it.startsWith("#HostName,IP,Score,Ping,Speed,CountryLong,CountryShort,") }) { "Unexpected feed schema" }
        val result = mutableListOf<VpnServer>()
        for (line in lines) {
            if (line.startsWith('*') || line.startsWith('#')) continue
            val f = fields(line)
            if (f.size < 15) continue
            val ip = f[1].trim(); val code = f[6].trim().uppercase(Locale.US)
            val config = f.last().trim()
            if (!ipv4(ip) || !countryCode.matches(code) || f[5].isBlank() || config.length !in 150..131072 || config.length % 4 != 0 || !configPattern.matches(config) || !configValid(config)) continue
            fun metric(index: Int): Long = (f[index].trim().toLongOrNull() ?: 0L).coerceAtLeast(0L)
            // Unknown latency sorts last; real high latency is retained instead of dropping a country.
            val ping = f[3].trim().toIntOrNull()?.takeIf { it > 0 }?.coerceAtMost(9998) ?: 9999
            result.add(VpnServer(f[0].trim(), ip, metric(2), ping, metric(4),
                f[5].trim(), code, metric(7), metric(8), metric(9), metric(10), f[11], f[12],
                f.subList(13,f.size-1).joinToString(","), config))
        }
        return result
    }
    /** Newest official row wins across sources; best score wins within each feed. */
    fun merge(primary: List<VpnServer>, secondary: List<VpnServer>): List<VpnServer> {
        fun unique(rows: List<VpnServer>) = rows.groupBy { it.ip }.mapValues { (_, group) -> group.maxByOrNull { it.score }!! }
        val merged = LinkedHashMap(unique(secondary)); merged.putAll(unique(primary))
        return merged.values.toList()
    }
}
