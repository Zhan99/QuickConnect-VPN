import pathlib, re, shutil, sys, xml.etree.ElementTree as ET
root=pathlib.Path(sys.argv[1]); base=pathlib.Path(__file__).resolve().parents[1]
app=root/'app'; src=app/'src/main'; pkg=src/'java/com/payaq/opengatevpn'
def edit(p,a,b):
    t=p.read_text(); assert a in t, f'Upstream changed: {p}: {a}'; p.write_text(t.replace(a,b,1))
edit(app/'build.gradle.kts','applicationId = "com.payaq.opengatevpn"','applicationId = "com.srcreationfarm.globalvpn"')
# API 37 uses the major.minor SDK package naming.
gradle=app/'build.gradle.kts'
t=gradle.read_text()
t=t.replace('version = release(37)\n', 'version = release(37) { minorApiLevel = 0 }\n')
gradle.write_text(t)
m=src/'AndroidManifest.xml'
edit(m,'android:name=".MainActivity"','android:name="com.payaq.opengatevpn.MainActivity"')
edit(m,'</application>','<activity android:name="com.payaq.opengatevpn.SrToolsActivity" android:exported="false" />\n</application>')
p=pkg/'MainActivity.kt'
imports = [
    'android.content.Intent',
    'androidx.compose.foundation.layout.Column',
    'androidx.compose.foundation.layout.Box',
    'androidx.compose.foundation.layout.fillMaxSize',
    'androidx.compose.foundation.layout.fillMaxWidth',
    'androidx.compose.foundation.layout.statusBarsPadding',
    'androidx.compose.material3.TextButton',
    'androidx.compose.material3.Text',
    'androidx.compose.ui.Modifier',
]
t = p.read_text()
missing = [f'import {name}' for name in imports if f'import {name}' not in t.splitlines()]
if missing:
    t, n = re.subn(r'(?m)^(package [^\n]+)$', lambda m: m.group(0) + '\n' + '\n'.join(missing), t, count=1)
    assert n == 1, 'MainActivity package declaration missing'
    p.write_text(t)
t=p.read_text(); pattern=r'(OpenGateVPNTheme\s*\{\s*)(MainScreen\s*\(\s*viewModel\s*=\s*viewModel,\s*onConnectClicked\s*=\s*::checkPermissionAndConnect\s*\))'
t,n=re.subn(pattern,r'''\1Column(Modifier.fillMaxSize()) {
 TextButton(onClick = { startActivity(Intent(this@MainActivity, SrToolsActivity::class.java)) }, modifier = Modifier.fillMaxWidth().statusBarsPadding()) { Text("IP check · Tools · About SR") }
 Box(Modifier.weight(1f)) { \2 }
}''',t,count=1); assert n==1,'MainActivity anchor changed'; p.write_text(t)
for p in pkg.rglob('*.kt'):
    t=p.read_text(); u=t.replace('"OpenGate VPN"','"SR Global VPN"').replace('"OpenGate"','"SR Global VPN"');
    if u!=t: p.write_text(u)
for p in (src/'res').glob('values*/strings.xml'):
    t=p.read_text(); u=re.sub(r'(<string\s+name="app_name"[^>]*>).*?(</string>)',r'\1SR Global VPN\2',t,flags=re.S)
    if t!=u: p.write_text(u)
# Country list derives from displayServers upstream; expose total and distinguish listing from connectivity.
servers_ui = pkg/'ui/main/ServersTab.kt'
edit(servers_ui, '"${viewModel.displayServers.size} Nodes Available"', '"${viewModel.displayServers.size} listed nodes · ${viewModel.availableCountries.size} countries/regions"')
edit(servers_ui, '// Search Bar', '''Text(text = "VPN Gate + recent mirror · connection not guaranteed", style = TechnicalData, color = TextMuted)
        // Search Bar''')
model_ui = pkg/'data/model/VpnServerDisplay.kt'
edit(model_ui, 'val pingText: String = "${ping}ms"', 'val pingText: String = if (ping == 9999) "Unknown" else "${ping}ms"')
# A stale selected country must not hide all nodes after a refresh.
vm = pkg/'ui/main/VpnViewModel.kt'
edit(vm, 'val matchesCountry = selectedCountryFilter?.let { it == server.countryLong } ?: true', 'val matchesCountry = selectedCountryFilter?.takeIf { it in availableCountries }?.let { it == server.countryLong } ?: true')
shutil.copytree(base/'overlay',root,dirs_exist_ok=True); ET.parse(m)
shutil.copy2(base/'LICENSE-SR', root/'LICENSE-SR')
print('SR overlay applied')
