# Permanent Error Prevention Log - SR Creation Farm

1. **Browser `net::ERR_EMPTY_RESPONSE` When VPN Connected**:
   - **Root Cause:** TCP port reachability checks (`Socket.connect`) alone matched public web servers on port 80/8080 that do not support HTTP `CONNECT` tunneling, returning empty responses to Chrome/WebView HTTPS requests. Also `LocalProxyBridge` needed strict byte-by-byte header draining for upstream `CONNECT` responses so TLS ClientHello bytes were never dropped.
   - **Correct Solution:** Updated `ServerRepository.kt` to verify real end-to-end `CONNECT www.google.com:443` / `SOCKS5` handshakes before accepting any node, added automatic node failover in `LocalProxyBridge.kt`, and added a "Switch Node" button in `dialog_info.xml`.
   - **Verification Status:** Verified all Kotlin/XML syntax and ZIP archive integrity.
