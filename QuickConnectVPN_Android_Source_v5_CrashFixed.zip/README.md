# QuickConnect VPN (v1.2.0 - Fixed ListenableFuture Runtime Crash)

Developed by **Shahriar Rahman** | **SR Creation Farm**
- YouTube: https://www.youtube.com/@SRCreation-farm
- Facebook: https://fb.com/srcreation.farm
