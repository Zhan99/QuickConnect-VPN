# Permanent Error Prevention Log - SR Creation Farm

1. **Runtime Crash: `NoClassDefFoundError: Failed resolution of: Lcom/google/common/util/concurrent/ListenableFuture;`**:
   - **Error Message:** `java.lang.NoClassDefFoundError: Failed resolution of: Lcom/google/common/util/concurrent/ListenableFuture;` triggered by `androidx.profileinstaller.ProfileInstallerInitializer` -> `androidx.concurrent.futures.AbstractResolvableFuture`.
   - **Root Cause:** Declaring `com.google.guava:listenablefuture:9999.0-empty-to-avoid-conflict-with-guava` without full Guava removes the `ListenableFuture` interface from the APK DEX, causing AndroidX `ProfileInstaller` (bundled with `appcompat:1.7.0`) to crash on a background thread ~5 seconds after app startup.
   - **Affected File:** `app/build.gradle.kts`
   - **Correct Solution:** Never use `9999.0-empty-to-avoid-conflict-with-guava` unless full `com.google.guava:guava` is also included. Instead, declare `implementation("androidx.concurrent:concurrent-futures:1.2.0")` and `implementation("com.google.guava:listenablefuture:1.0")` so the real `ListenableFuture` class is compiled into `classes.dex`.
   - **Verification Status:** Verified all Kotlin/XML syntax and ZIP archive integrity.
