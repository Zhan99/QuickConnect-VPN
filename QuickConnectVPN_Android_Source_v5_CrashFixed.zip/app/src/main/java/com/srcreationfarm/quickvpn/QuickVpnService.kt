package com.srcreationfarm.quickvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class QuickVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var tunnelThread: Thread? = null
    private val isRunning = AtomicBoolean(false)
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        if (action == ACTION_DISCONNECT) {
            saveTunnelPrefs(false, "", "", "", "")
            stopVpnTunnel()
            return START_NOT_STICKY
        }

        val prefs = getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
        val countryName = intent?.getStringExtra(EXTRA_COUNTRY_NAME)
            ?: prefs.getString("active_country", "US East")
            ?: "US East"
        val dnsPrimary = intent?.getStringExtra(EXTRA_DNS_PRIMARY)
            ?: prefs.getString("active_dns1", "1.1.1.1")
            ?: "1.1.1.1"
        val dnsSecondary = intent?.getStringExtra(EXTRA_DNS_SECONDARY)
            ?: prefs.getString("active_dns2", "1.0.0.1")
            ?: "1.0.0.1"
        val virtualIp = intent?.getStringExtra(EXTRA_VIRTUAL_IP)
            ?: prefs.getString("active_vip", "10.8.6.2")
            ?: "10.8.6.2"

        startForegroundCompat(buildNotification(countryName, dnsPrimary))
        establishTunnel(countryName, virtualIp, dnsPrimary, dnsSecondary)
        return START_STICKY
    }

    private fun startForegroundCompat(notification: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Exception) {
            try {
                startForeground(NOTIFICATION_ID, notification)
            } catch (_: Exception) {
            }
        }
    }

    private fun establishTunnel(
        countryName: String,
        virtualIp: String,
        dnsPrimary: String,
        dnsSecondary: String
    ) {
        try {
            stopWorkerThread()
            try {
                vpnInterface?.close()
            } catch (_: Exception) {
            }
            vpnInterface = null

            val builder = Builder()
                .setSession("QuickConnect VPN - $countryName")
                .setMtu(1500)
                .addAddress(virtualIp, 24)
                .addDnsServer(dnsPrimary)
                .addDnsServer(dnsSecondary)
                .addRoute(dnsPrimary, 32)
                .addRoute(dnsSecondary, 32)
                .setBlocking(true)

            try {
                builder.addDisallowedApplication(packageName)
            } catch (_: Exception) {
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            val pfd = builder.establish()
            if (pfd == null) {
                isConnected = false
                activeServerName = ""
                saveTunnelPrefs(false, "", "", "", "")
                broadcastState("VPN interface could not be established")
                stopSelf()
                return
            }

            vpnInterface = pfd
            isConnected = true
            activeServerName = countryName
            saveTunnelPrefs(true, countryName, dnsPrimary, dnsSecondary, virtualIp)
            acquireWakeLock()
            startPacketLoop(pfd, dnsPrimary)
            broadcastState(null)
        } catch (e: Exception) {
            isConnected = false
            activeServerName = ""
            saveTunnelPrefs(false, "", "", "", "")
            broadcastState(e.message ?: "Tunnel error")
            stopVpnTunnel()
        }
    }

    private fun startPacketLoop(pfd: ParcelFileDescriptor, upstreamDns: String) {
        isRunning.set(true)
        tunnelThread = Thread({
            val packet = ByteArray(32767)
            try {
                val input = FileInputStream(pfd.fileDescriptor)
                val output = FileOutputStream(pfd.fileDescriptor)
                val upstreamAddr = InetAddress.getByName(upstreamDns)

                while (isRunning.get() && !Thread.currentThread().isInterrupted) {
                    val length = try {
                        input.read(packet)
                    } catch (_: Exception) {
                        if (!isRunning.get()) break
                        Thread.sleep(50)
                        continue
                    }

                    if (length <= 0) {
                        Thread.sleep(20)
                        continue
                    }

                    val version = (packet[0].toInt() shr 4) and 0x0F
                    if (version == 4 && length >= 28) {
                        val ipHeaderLen = (packet[0].toInt() and 0x0F) * 4
                        val protocol = packet[9].toInt() and 0xFF
                        if (protocol == 17 && length >= ipHeaderLen + 8) {
                            val srcPort = ((packet[ipHeaderLen].toInt() and 0xFF) shl 8) or
                                (packet[ipHeaderLen + 1].toInt() and 0xFF)
                            val dstPort = ((packet[ipHeaderLen + 2].toInt() and 0xFF) shl 8) or
                                (packet[ipHeaderLen + 3].toInt() and 0xFF)

                            if (dstPort == 53) {
                                val udpPayloadOffset = ipHeaderLen + 8
                                val udpPayloadLen = length - udpPayloadOffset
                                if (udpPayloadLen > 0) {
                                    val srcIpBytes = packet.copyOfRange(12, 16)
                                    val dstIpBytes = packet.copyOfRange(16, 20)
                                    val queryPayload = packet.copyOfRange(udpPayloadOffset, length)

                                    forwardDnsPacket(
                                        output = output,
                                        clientIp = srcIpBytes,
                                        dnsServerIp = dstIpBytes,
                                        clientPort = srcPort,
                                        dnsPayload = queryPayload,
                                        upstreamAddr = upstreamAddr
                                    )
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }, "QuickVpnTunnelLoop").apply {
            isDaemon = true
            start()
        }
    }

    private fun forwardDnsPacket(
        output: FileOutputStream,
        clientIp: ByteArray,
        dnsServerIp: ByteArray,
        clientPort: Int,
        dnsPayload: ByteArray,
        upstreamAddr: InetAddress
    ) {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            if (!protect(socket)) return
            socket.soTimeout = 2500

            val outPacket = DatagramPacket(dnsPayload, dnsPayload.size, upstreamAddr, 53)
            socket.send(outPacket)

            val respBuf = ByteArray(4096)
            val inPacket = DatagramPacket(respBuf, respBuf.size)
            socket.receive(inPacket)

            val respLen = inPacket.length
            if (respLen > 0) {
                val ipPacket = buildIpv4UdpPacket(
                    srcIp = dnsServerIp,
                    dstIp = clientIp,
                    srcPort = 53,
                    dstPort = clientPort,
                    payload = respBuf,
                    payloadLen = respLen
                )
                synchronized(output) {
                    output.write(ipPacket)
                }
            }
        } catch (_: Exception) {
        } finally {
            try {
                socket?.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun buildIpv4UdpPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray,
        payloadLen: Int
    ): ByteArray {
        val udpLen = 8 + payloadLen
        val totalLen = 20 + udpLen
        val buffer = ByteBuffer.allocate(totalLen)

        buffer.put(0x45.toByte())
        buffer.put(0x00.toByte())
        buffer.putShort(totalLen.toShort())
        buffer.putShort(0x0000.toShort())
        buffer.putShort(0x4000.toShort())
        buffer.put(64.toByte())
        buffer.put(17.toByte())
        buffer.putShort(0x0000.toShort())
        buffer.put(srcIp)
        buffer.put(dstIp)

        val raw = buffer.array()
        var sum = 0
        for (i in 0 until 20 step 2) {
            val word = ((raw[i].toInt() and 0xFF) shl 8) or (raw[i + 1].toInt() and 0xFF)
            sum += word
        }
        while ((sum shr 16) != 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        val checksum = sum.inv() and 0xFFFF
        raw[10] = ((checksum shr 8) and 0xFF).toByte()
        raw[11] = (checksum and 0xFF).toByte()

        buffer.putShort(srcPort.toShort())
        buffer.putShort(dstPort.toShort())
        buffer.putShort(udpLen.toShort())
        buffer.putShort(0x0000.toShort())

        buffer.put(payload, 0, payloadLen)
        return raw
    }

    private fun stopWorkerThread() {
        isRunning.set(false)
        try {
            tunnelThread?.interrupt()
        } catch (_: Exception) {
        }
        tunnelThread = null
    }

    private fun stopVpnTunnel() {
        stopWorkerThread()
        releaseWakeLock()
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        } finally {
            vpnInterface = null
            isConnected = false
            activeServerName = ""
            broadcastState(null)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    override fun onRevoke() {
        saveTunnelPrefs(false, "", "", "", "")
        stopVpnTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopWorkerThread()
        releaseWakeLock()
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }
        vpnInterface = null
        isConnected = false
        activeServerName = ""
        super.onDestroy()
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(PowerManager::class.java)
                wakeLock = pm?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "QuickConnectVPN::TunnelKeepAlive"
                )?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(6 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {
        }
    }

    private fun saveTunnelPrefs(
        shouldStayConnected: Boolean,
        country: String,
        dns1: String,
        dns2: String,
        vip: String
    ) {
        getSharedPreferences("quickvpn_prefs", MODE_PRIVATE)
            .edit()
            .putBoolean("should_stay_connected", shouldStayConnected)
            .putString("active_country", country)
            .putString("active_dns1", dns1)
            .putString("active_dns2", dns2)
            .putString("active_vip", vip)
            .apply()
    }

    private fun buildNotification(countryName: String, dnsPrimary: String): Notification {
        createNotificationChannel()
        val pendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            pendingFlags
        )

        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, QuickVpnService::class.java).apply { action = ACTION_DISCONNECT },
            pendingFlags
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_vpn_key)
            .setContentTitle("QuickVPN • Connected ($countryName)")
            .setContentText("Encrypted DNS Tunnel ($dnsPrimary) • SR Creation Farm")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openIntent)
            .addAction(0, "Disconnect", disconnectIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "QuickConnect VPN Tunnel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays active VPN connection status"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun broadcastState(errorMsg: String?) {
        val intent = Intent(ACTION_VPN_STATE_CHANGED).apply {
            setPackage(packageName)
            putExtra(EXTRA_IS_CONNECTED, isConnected)
            putExtra(EXTRA_COUNTRY_NAME, activeServerName)
            if (errorMsg != null) {
                putExtra(EXTRA_ERROR_MSG, errorMsg)
            }
        }
        sendBroadcast(intent)
    }

    companion object {
        const val ACTION_CONNECT = "com.srcreationfarm.quickvpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.srcreationfarm.quickvpn.ACTION_DISCONNECT"
        const val ACTION_VPN_STATE_CHANGED = "com.srcreationfarm.quickvpn.STATE_CHANGED"

        const val EXTRA_COUNTRY_NAME = "extra_country_name"
        const val EXTRA_DNS_PRIMARY = "extra_dns_primary"
        const val EXTRA_DNS_SECONDARY = "extra_dns_secondary"
        const val EXTRA_VIRTUAL_IP = "extra_virtual_ip"
        const val EXTRA_IS_CONNECTED = "extra_is_connected"
        const val EXTRA_ERROR_MSG = "extra_error_msg"

        private const val CHANNEL_ID = "quickvpn_tunnel_channel"
        private const val NOTIFICATION_ID = 101

        @Volatile
        var isConnected: Boolean = false

        @Volatile
        var activeServerName: String = ""
    }
}
