"""Offline structural checks for the source overlay before fetching dependencies."""
import ast
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
for name in ('scripts/prepare.py', 'scripts/check_apk.py', 'README.md', 'LICENSE-SR'):
    assert (root / name).is_file(), f'Missing {name}'
for path in (root / 'scripts').glob('*.py'):
    ast.parse(path.read_text(), filename=str(path))
for path in (root / 'overlay').rglob('*.xml'):
    ET.parse(path)
source = root / 'overlay/app/src/main/java/com/payaq/opengatevpn/SrToolsActivity.kt'
assert source.is_file() and 'class SrToolsActivity' in source.read_text()
workflow = (root / '.github/workflows/build.yml').read_text()
assert "packages: 'platform-tools platforms;android-34 platforms;android-37 build-tools;36.0.0'" in workflow
print('Build kit structure, Python syntax, XML and explicit SDK package list: OK')
